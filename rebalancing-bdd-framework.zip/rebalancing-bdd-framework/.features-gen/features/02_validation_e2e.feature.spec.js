// Generated from: features\02_validation_e2e.feature
import { test } from "../../src/fixtures/fixtures.js";

test.describe('Invalid input is rejected end to end', () => {

  test.beforeEach('Background', async ({ Given, rebalancePage }, testInfo) => { if (testInfo.error) return;
    await Given('I open the Portfolio Rebalancer application', null, { rebalancePage }); 
  });
  
  test('Target allocation that does not total 100% is rejected, corrected and rebalanced', { tag: ['@regression', '@e2e', '@smoke', '@sanity', '@P1', '@E2E-07'] }, async ({ When, Then, And, rebalancePage }) => { 
    await When('I set the "target" of security "IBM" to "10"', null, { rebalancePage }); 
    await And('I click Calculate', null, { rebalancePage }); 
    await Then('I should see the error "Total target % must equal 100 (currently 90)"', null, { rebalancePage }); 
    await And('no trade output should be displayed', null, { rebalancePage }); 
    await When('I set the "target" of security "IBM" to "20"', null, { rebalancePage }); 
    await And('I click Calculate', null, { rebalancePage }); 
    await Then('no validation errors should be displayed', null, { rebalancePage }); 
    await And('"IBM" should show action "BUY" with "66" shares', null, { rebalancePage }); 
    await And('"ORCL" should show action "SELL" with "45" shares', null, { rebalancePage }); 
  });

  test.describe('Invalid input is rejected - <case>', () => {

    test('Invalid input is rejected - current total not 100', { tag: ['@regression', '@e2e', '@P2', '@E2E-08'] }, async ({ When, Then, And, rebalancePage }) => { 
      await When('I set the "current" of security "IBM" to "20"', null, { rebalancePage }); 
      await And('I click Calculate', null, { rebalancePage }); 
      await Then('I should see the error "Total current % must equal 100 (currently 110)"', null, { rebalancePage }); 
      await And('no trade output should be displayed', null, { rebalancePage }); 
    });

    test('Invalid input is rejected - zero total asset', { tag: ['@regression', '@e2e', '@P2', '@E2E-08'] }, async ({ When, Then, And, rebalancePage }) => { 
      await When('I enter total asset "0"', null, { rebalancePage }); 
      await And('I click Calculate', null, { rebalancePage }); 
      await Then('I should see the error "Total asset must be a positive number"', null, { rebalancePage }); 
      await And('no trade output should be displayed', null, { rebalancePage }); 
    });

    test('Invalid input is rejected - vested above 100%', { tag: ['@regression', '@e2e', '@P2', '@E2E-08'] }, async ({ When, Then, And, rebalancePage }) => { 
      await When('I enter vested percentage "101"', null, { rebalancePage }); 
      await And('I click Calculate', null, { rebalancePage }); 
      await Then('I should see the error "Vested percentage must be greater than 0 and at most 100"', null, { rebalancePage }); 
      await And('no trade output should be displayed', null, { rebalancePage }); 
    });

    test('Invalid input is rejected - zero unit price', { tag: ['@regression', '@e2e', '@P2', '@E2E-08'] }, async ({ When, Then, And, rebalancePage }) => { 
      await When('I set the "price" of security "IBM" to "0"', null, { rebalancePage }); 
      await And('I click Calculate', null, { rebalancePage }); 
      await Then('I should see the error "Unit price for IBM must be greater than 0"', null, { rebalancePage }); 
      await And('no trade output should be displayed', null, { rebalancePage }); 
    });

    test('Invalid input is rejected - duplicate security', { tag: ['@regression', '@e2e', '@P2', '@E2E-08'] }, async ({ When, Then, And, rebalancePage }) => { 
      await When('I set the "symbol" of security "MSFT" to "IBM"', null, { rebalancePage }); 
      await And('I click Calculate', null, { rebalancePage }); 
      await Then('I should see the error "Duplicate security: IBM"', null, { rebalancePage }); 
      await And('no trade output should be displayed', null, { rebalancePage }); 
    });

  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features\\02_validation_e2e.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":10,"pickleLine":10,"tags":["@regression","@e2e","@smoke","@sanity","@P1","@E2E-07"],"steps":[{"pwStepLine":7,"gherkinStepLine":7,"keywordType":"Context","textWithKeyword":"Given I open the Portfolio Rebalancer application","isBg":true,"stepMatchArguments":[]},{"pwStepLine":11,"gherkinStepLine":11,"keywordType":"Action","textWithKeyword":"When I set the \"target\" of security \"IBM\" to \"10\"","stepMatchArguments":[{"group":{"start":10,"value":"\"target\"","children":[{"start":11,"value":"target","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":31,"value":"\"IBM\"","children":[{"start":32,"value":"IBM","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":40,"value":"\"10\"","children":[{"start":41,"value":"10","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":12,"gherkinStepLine":12,"keywordType":"Action","textWithKeyword":"And I click Calculate","stepMatchArguments":[]},{"pwStepLine":13,"gherkinStepLine":13,"keywordType":"Outcome","textWithKeyword":"Then I should see the error \"Total target % must equal 100 (currently 90)\"","stepMatchArguments":[{"group":{"start":23,"value":"\"Total target % must equal 100 (currently 90)\"","children":[{"start":24,"value":"Total target % must equal 100 (currently 90)","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":14,"gherkinStepLine":14,"keywordType":"Outcome","textWithKeyword":"And no trade output should be displayed","stepMatchArguments":[]},{"pwStepLine":15,"gherkinStepLine":15,"keywordType":"Action","textWithKeyword":"When I set the \"target\" of security \"IBM\" to \"20\"","stepMatchArguments":[{"group":{"start":10,"value":"\"target\"","children":[{"start":11,"value":"target","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":31,"value":"\"IBM\"","children":[{"start":32,"value":"IBM","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":40,"value":"\"20\"","children":[{"start":41,"value":"20","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":16,"gherkinStepLine":16,"keywordType":"Action","textWithKeyword":"And I click Calculate","stepMatchArguments":[]},{"pwStepLine":17,"gherkinStepLine":17,"keywordType":"Outcome","textWithKeyword":"Then no validation errors should be displayed","stepMatchArguments":[]},{"pwStepLine":18,"gherkinStepLine":18,"keywordType":"Outcome","textWithKeyword":"And \"IBM\" should show action \"BUY\" with \"66\" shares","stepMatchArguments":[{"group":{"start":0,"value":"\"IBM\"","children":[{"start":1,"value":"IBM","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":25,"value":"\"BUY\"","children":[{"start":26,"value":"BUY","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":36,"value":"\"66\"","children":[{"start":37,"value":"66","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":19,"gherkinStepLine":19,"keywordType":"Outcome","textWithKeyword":"And \"ORCL\" should show action \"SELL\" with \"45\" shares","stepMatchArguments":[{"group":{"start":0,"value":"\"ORCL\"","children":[{"start":1,"value":"ORCL","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":26,"value":"\"SELL\"","children":[{"start":27,"value":"SELL","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":38,"value":"\"45\"","children":[{"start":39,"value":"45","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":24,"pickleLine":30,"tags":["@regression","@e2e","@P2","@E2E-08"],"steps":[{"pwStepLine":7,"gherkinStepLine":7,"keywordType":"Context","textWithKeyword":"Given I open the Portfolio Rebalancer application","isBg":true,"stepMatchArguments":[]},{"pwStepLine":25,"gherkinStepLine":23,"keywordType":"Action","textWithKeyword":"When I set the \"current\" of security \"IBM\" to \"20\"","stepMatchArguments":[{"group":{"start":10,"value":"\"current\"","children":[{"start":11,"value":"current","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":32,"value":"\"IBM\"","children":[{"start":33,"value":"IBM","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":41,"value":"\"20\"","children":[{"start":42,"value":"20","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":26,"gherkinStepLine":24,"keywordType":"Action","textWithKeyword":"And I click Calculate","stepMatchArguments":[]},{"pwStepLine":27,"gherkinStepLine":25,"keywordType":"Outcome","textWithKeyword":"Then I should see the error \"Total current % must equal 100 (currently 110)\"","stepMatchArguments":[{"group":{"start":23,"value":"\"Total current % must equal 100 (currently 110)\"","children":[{"start":24,"value":"Total current % must equal 100 (currently 110)","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":28,"gherkinStepLine":26,"keywordType":"Outcome","textWithKeyword":"And no trade output should be displayed","stepMatchArguments":[]}]},
  {"pwTestLine":31,"pickleLine":31,"tags":["@regression","@e2e","@P2","@E2E-08"],"steps":[{"pwStepLine":7,"gherkinStepLine":7,"keywordType":"Context","textWithKeyword":"Given I open the Portfolio Rebalancer application","isBg":true,"stepMatchArguments":[]},{"pwStepLine":32,"gherkinStepLine":23,"keywordType":"Action","textWithKeyword":"When I enter total asset \"0\"","stepMatchArguments":[{"group":{"start":20,"value":"\"0\"","children":[{"start":21,"value":"0","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":33,"gherkinStepLine":24,"keywordType":"Action","textWithKeyword":"And I click Calculate","stepMatchArguments":[]},{"pwStepLine":34,"gherkinStepLine":25,"keywordType":"Outcome","textWithKeyword":"Then I should see the error \"Total asset must be a positive number\"","stepMatchArguments":[{"group":{"start":23,"value":"\"Total asset must be a positive number\"","children":[{"start":24,"value":"Total asset must be a positive number","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":35,"gherkinStepLine":26,"keywordType":"Outcome","textWithKeyword":"And no trade output should be displayed","stepMatchArguments":[]}]},
  {"pwTestLine":38,"pickleLine":32,"tags":["@regression","@e2e","@P2","@E2E-08"],"steps":[{"pwStepLine":7,"gherkinStepLine":7,"keywordType":"Context","textWithKeyword":"Given I open the Portfolio Rebalancer application","isBg":true,"stepMatchArguments":[]},{"pwStepLine":39,"gherkinStepLine":23,"keywordType":"Action","textWithKeyword":"When I enter vested percentage \"101\"","stepMatchArguments":[{"group":{"start":26,"value":"\"101\"","children":[{"start":27,"value":"101","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":40,"gherkinStepLine":24,"keywordType":"Action","textWithKeyword":"And I click Calculate","stepMatchArguments":[]},{"pwStepLine":41,"gherkinStepLine":25,"keywordType":"Outcome","textWithKeyword":"Then I should see the error \"Vested percentage must be greater than 0 and at most 100\"","stepMatchArguments":[{"group":{"start":23,"value":"\"Vested percentage must be greater than 0 and at most 100\"","children":[{"start":24,"value":"Vested percentage must be greater than 0 and at most 100","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":42,"gherkinStepLine":26,"keywordType":"Outcome","textWithKeyword":"And no trade output should be displayed","stepMatchArguments":[]}]},
  {"pwTestLine":45,"pickleLine":33,"tags":["@regression","@e2e","@P2","@E2E-08"],"steps":[{"pwStepLine":7,"gherkinStepLine":7,"keywordType":"Context","textWithKeyword":"Given I open the Portfolio Rebalancer application","isBg":true,"stepMatchArguments":[]},{"pwStepLine":46,"gherkinStepLine":23,"keywordType":"Action","textWithKeyword":"When I set the \"price\" of security \"IBM\" to \"0\"","stepMatchArguments":[{"group":{"start":10,"value":"\"price\"","children":[{"start":11,"value":"price","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":30,"value":"\"IBM\"","children":[{"start":31,"value":"IBM","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":39,"value":"\"0\"","children":[{"start":40,"value":"0","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":47,"gherkinStepLine":24,"keywordType":"Action","textWithKeyword":"And I click Calculate","stepMatchArguments":[]},{"pwStepLine":48,"gherkinStepLine":25,"keywordType":"Outcome","textWithKeyword":"Then I should see the error \"Unit price for IBM must be greater than 0\"","stepMatchArguments":[{"group":{"start":23,"value":"\"Unit price for IBM must be greater than 0\"","children":[{"start":24,"value":"Unit price for IBM must be greater than 0","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":49,"gherkinStepLine":26,"keywordType":"Outcome","textWithKeyword":"And no trade output should be displayed","stepMatchArguments":[]}]},
  {"pwTestLine":52,"pickleLine":34,"tags":["@regression","@e2e","@P2","@E2E-08"],"steps":[{"pwStepLine":7,"gherkinStepLine":7,"keywordType":"Context","textWithKeyword":"Given I open the Portfolio Rebalancer application","isBg":true,"stepMatchArguments":[]},{"pwStepLine":53,"gherkinStepLine":23,"keywordType":"Action","textWithKeyword":"When I set the \"symbol\" of security \"MSFT\" to \"IBM\"","stepMatchArguments":[{"group":{"start":10,"value":"\"symbol\"","children":[{"start":11,"value":"symbol","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":31,"value":"\"MSFT\"","children":[{"start":32,"value":"MSFT","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":41,"value":"\"IBM\"","children":[{"start":42,"value":"IBM","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":54,"gherkinStepLine":24,"keywordType":"Action","textWithKeyword":"And I click Calculate","stepMatchArguments":[]},{"pwStepLine":55,"gherkinStepLine":25,"keywordType":"Outcome","textWithKeyword":"Then I should see the error \"Duplicate security: IBM\"","stepMatchArguments":[{"group":{"start":23,"value":"\"Duplicate security: IBM\"","children":[{"start":24,"value":"Duplicate security: IBM","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":56,"gherkinStepLine":26,"keywordType":"Outcome","textWithKeyword":"And no trade output should be displayed","stepMatchArguments":[]}]},
]; // bdd-data-end