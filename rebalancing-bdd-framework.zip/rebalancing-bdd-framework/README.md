# Portfolio Rebalancer BDD - New Joiner Guide

**Package name:** `portfolio-rebalancer-bdd`

This project is a JavaScript UI automation framework using **Playwright**,
**BDD/Gherkin**, and the **Page Object Model (POM)**. It tests portfolio
rebalancing: calculating how many shares to BUY or SELL to move an account
toward its target allocation.

The project includes a small **reference web application** so you can run the
tests locally without an external deployment. It is not a connection to a
production trading system: there is no authentication, backend persistence,
market-price feed, or actual order execution.

> The package has been renamed, but the local folder may still be named
> `rebalancing-bdd-framework` because Windows blocked its rename. Run commands
> from the folder containing [package.json](./package.json), regardless of its
> folder name.

## Contents

1. [Understand the business flow](#1-understand-the-business-flow)
2. [Set up and run your first test](#2-set-up-and-run-your-first-test)
3. [Understand the execution flow](#3-understand-the-execution-flow)
4. [Learn the role of each file](#4-learn-the-role-of-each-file)
5. [Configure environments](#5-configure-environments)
6. [Select suites, priorities, and browsers](#6-select-suites-priorities-and-browsers)
7. [Understand the existing test coverage](#7-understand-the-existing-test-coverage)
8. [Read reports and debug failures](#8-read-reports-and-debug-failures)
9. [Add or maintain a test](#9-add-or-maintain-a-test)
10. [Understand the CI pipeline](#10-understand-the-ci-pipeline)
11. [Troubleshooting](#11-troubleshooting)
12. [New joiner checklist and presentation flow](#12-new-joiner-checklist-and-presentation-flow)

## 1. Understand the business flow

### User journey

1. Open the Portfolio Rebalancer.
2. Enter an account name, total asset value, and vested percentage.
3. Review or edit holdings: security symbol, target %, current %, and unit price.
4. Optionally add/remove securities or enable fractional shares.
5. Click **Calculate**.
6. If input is invalid, read the validation errors, correct it, and calculate again.
7. If valid, review each security's action, share quantity, and trade value.
8. Review the summary: investable asset, total buys, total sells, and residual cash.
9. Edit inputs to clear stale results, or click **Reset** to restore defaults.

The tests exercise these steps through the browser. The "after applying the
trades" assertion simulates the result mathematically; it does not click a
trade-submission button or execute orders.

### Assumptions

These rules describe the reference app and the test expectations.

| Rule | Behavior |
|------|----------|
| Investable asset | `totalAsset * vested / 100` |
| Variance | `currentPercent - targetPercent` |
| Action | Negative variance: BUY; positive: SELL; absolute variance below `0.0001`: HOLD |
| Exact share quantity | `abs(variance) / 100 * investableAsset / unitPrice` |
| Whole shares | `Math.floor(exactShares + 1e-9)`; the small epsilon reduces floating-point floor errors |
| Fractional shares | Rounded to 4 decimal places, not unlimited precision |
| Trade value | `shares * unitPrice` |
| Residual cash | Total sell value minus total buy value; negative means additional cash is needed |
| Valid account inputs | Total asset > 0; vested percentage > 0 and <= 100 |
| Valid holdings | Required, unique, case-insensitive symbols; percentages between 0 and 100; prices > 0; at least one row |
| Allocation totals | Target and current each total 100 within tolerance `0.0001` |
| Prices and costs | Prices are fixed; no fees, taxes, market changes, or lot-size rules |
| Formatting | Summary and trade values display 2 decimals; thousands separators in numeric inputs are not accepted |

**Whole shares cannot generally reach exact zero variance.** The business-goal
assertion checks each post-trade deviation against one share's price with a
$0.01 numerical allowance. Fractional quantities also retain a small rounding
residual; they are not a guarantee of mathematically exact target values.

### Default assessment example

Account **ABC**, total asset **$100,000**, vested **100%**, whole-share mode:

| Security | Target % | Current % | Variance | Price | Action | Shares | Trade value |
|----------|---------:|----------:|---------:|------:|--------|-------:|------------:|
| IBM | 20 | 10 | -10 | 150 | BUY | 66 | $9,900 |
| MSFT | 20 | 20 | 0 | 90 | HOLD | 0 | $0 |
| ORCL | 20 | 30 | 10 | 220 | SELL | 45 | $9,900 |
| AAPL | 20 | 20 | 0 | 450 | HOLD | 0 | $0 |
| HD | 20 | 20 | 0 | 70 | HOLD | 0 | $0 |

IBM needs `$10,000 / $150 = 66.666...` shares, rounded down to 66.
ORCL needs `$10,000 / $220 = 45.454...` shares sold, rounded down to 45.
Both trade values are $9,900, so residual cash is $0.

## 2. Set up and run your first test

### Step 1 - Install prerequisites

- Use a supported Node.js LTS version **22 or newer**, with npm available.
  The current GitHub workflow explicitly uses Node.js 20; local setup does not
  require matching that version exactly. The package's `engines` field says
  `>=18`, but individual dependencies can require newer Node.js versions.
- Install Git if you will clone the repository.
- Use an editor such as VS Code.
- Ensure package installation and Playwright browser downloads are permitted
  on your network.

### Step 2 - Open the project root

Open the folder containing [package.json](./package.json) in VS Code, then
open a terminal there. Check:

```powershell
Get-Location
node --version
npm --version
```

### Step 3 - Install the locked dependencies

```powershell
npm ci
```

This installs the versions recorded in [package-lock.json](./package-lock.json).
Use `npm ci` for a clean, reproducible onboarding or CI install. Do not
manually edit installed dependencies.

### Step 4 - Install browser binaries

```powershell
npm run install:browsers
```

For a smaller first-time download, install only Chromium:

```powershell
npx playwright install chromium
```

Playwright-managed Chromium, Firefox, and WebKit binaries are separate from
your everyday browser installations.

### Step 5 - Review the local environment

Read [config/.env.local](./config/.env.local). By default it selects:

- URL `http://localhost:3000`.
- Automatic local app startup.
- Chromium, Firefox, and WebKit.
- Headless execution and workers equal to 50% of available CPU cores.
- Account ABC, total asset 100000, vested 100.

No separate application-start command is required for normal local tests.

### Step 6 - Run the smallest useful suite

```powershell
npm run test:smoke -- --project=chromium
```

Expected selection: **2 tests** on Chromium. Playwright starts the local
server when needed, opens isolated browser contexts, and runs the two smoke
journeys.

### Step 7 - Open the result report

```powershell
npm run report
```

Review the scenario names, Gherkin steps, durations, and any failure evidence.
For all three default browsers:

```powershell
npm run test:smoke
```

Expected selection: **6 tests** = 2 smoke tests x 3 browsers.

### Optional - Explore the reference app manually

```powershell
npm run app
```

Open `http://localhost:3000`. Stop this manual server using `Ctrl+C` in its
terminal when finished. This script uses `APP_PORT` from the shell or defaults
to 3000; it does **not** load the environment files by itself.

## 3. Understand the execution flow

### What happens when you run `npm test`

```text
npm script
  -> bddgen
       -> playwright.config.js loads src/utils/env.js
       -> selected config/.env.<TEST_ENV> is loaded
       -> feature files + step definitions + fixtures are discovered
       -> TAGS expression selects scenarios, if configured
       -> runnable Playwright tests are written to .features-gen
  -> playwright test
       -> configuration selects browser projects, workers, and reporters
       -> local server is started/reused if enabled
       -> a fresh browser context/page is supplied for each test
       -> rebalancePage fixture creates the page object and components
       -> Background and scenario steps execute in order
       -> assertions compare UI output with expected results
       -> reports and configured failure artifacts are written
```

`bddgen` comes from **playwright-bdd**. This project uses Playwright Test as
the runner, not a separate Cucumber.js runner. Gherkin is translated into
Playwright tests before execution.

**Do not edit generated tests.** Edit feature files or source steps, then
regenerate. All `test:*` suite scripts perform generation automatically.

### Trace one concrete step

For `When I click Calculate`:

1. [features/01_rebalance_e2e.feature](./features/01_rebalance_e2e.feature)
   describes the business action.
2. [src/steps/common.steps.js](./src/steps/common.steps.js) matches that text.
3. [src/fixtures/fixtures.js](./src/fixtures/fixtures.js) supplies `rebalancePage`.
4. [src/pages/RebalancePage.js](./src/pages/RebalancePage.js) clicks Calculate
   and waits for either the visible summary or a validation-error box.
5. [app/rebalancer.js](./app/rebalancer.js), running inside the browser,
   validates inputs and renders results or errors.
6. Subsequent `Then` steps read the UI through the POM and assert the outcome.

This separation keeps business-readable scenarios independent of selectors.

## 4. Learn the role of each file

### Root configuration and documentation

| File | Purpose | When to change it |
|------|---------|-------------------|
| [package.json](./package.json) | Package identity, npm commands, dependency ranges, and Node engine declaration | Add a shared execution command or intentionally change dependencies |
| [package-lock.json](./package-lock.json) | Exact dependency versions for reproducible installation | Let npm update it when changing dependencies; commit with the manifest |
| [playwright.config.js](./playwright.config.js) | BDD discovery/generation settings, browser project map, parallelism, retries, timeouts, server startup, and reporters | Change runner-wide behavior or add browser configurations |
| [.gitignore](./.gitignore) | Excludes dependencies, generated tests, reports, execution artifacts, and root `.env` | Adjust ignored outputs; never rely on it alone to protect secrets |
| [README.md](./README.md) | This onboarding and maintenance guide | Update when framework behavior or commands change |
| [docs/TEST_CASES.md](./docs/TEST_CASES.md) | Manual steps, inputs, expected results, and IDs matching automated cases | Update when scenarios or expected business behavior change |
| [.github/workflows/playwright-bdd.yml](./.github/workflows/playwright-bdd.yml) | GitHub Actions execution and artifact publication | Change CI triggers, environments, matrix, or pipeline steps |

### Application under test

| File | Purpose |
|------|---------|
| [app/index.html](./app/index.html) | Account form, holdings table, buttons, validation area, and summary; exposes stable `data-testid` attributes |
| [app/styles.css](./app/styles.css) | Reference-app layout and BUY/SELL/HOLD styling |
| [app/rebalancer.js](./app/rebalancer.js) | Default account/holdings, row management, input validation, calculation, result clearing, and reset |
| [scripts/server.js](./scripts/server.js) | Dependency-free Node HTTP server serving the app directory; uses `APP_PORT` or 3000 |

The app calculation and the test oracle are deliberately separate. Tests
should not import application calculation code to generate expected output.

### Environment and shared test data

| File | Purpose |
|------|---------|
| [config/.env.local](./config/.env.local) | Local URL, automatic server startup, default browser/execution settings, and account inputs |
| [config/.env.qa](./config/.env.qa) | QA settings; currently contains a placeholder URL and disables local server startup |
| [config/.env.uat](./config/.env.uat) | UAT/staging settings; currently contains a placeholder URL, disables local startup, and includes Edge |
| [src/utils/env.js](./src/utils/env.js) | Selects the environment file, preserves shell/CI overrides, and exports normalized settings as `env` |
| [test-data/portfolios.json](./test-data/portfolios.json) | Named account/holdings datasets consumed by the portfolio-loading step |
| [src/utils/rebalanceCalculator.js](./src/utils/rebalanceCalculator.js) | Independent test oracle (`calculateRebalance`) and mathematical post-trade simulation (`applyTrades`) |

The datasets are:

| Dataset key | Intent |
|-------------|--------|
| `heavyRebalance` | Multiple buys and sells; every holding needs a trade |
| `newAndExitPositions` | Open zero-current positions and exit zero-target positions |
| `decimalPortfolio` | Decimal allocation percentages and prices |
| `highValueAccount` | Billion-dollar account for numeric precision checks |
| `boundaryAllocation` | 0% and 100% target/current endpoints |
| `minimalVariance` | Opposite 0.01-percentage-point deviations at a unit price of $1 |

### Page Object Model and fixtures

| File | Responsibility and important methods |
|------|--------------------------------------|
| [src/pages/BasePage.js](./src/pages/BasePage.js) | Shared Playwright page, navigation (`navigate`), title reading, and test-ID locator helper (`byTestId`) |
| [src/pages/RebalancePage.js](./src/pages/RebalancePage.js) | Main form and buttons; `open`, `setAccount`, `getAccount`, `setFractionalShares`, `calculate`, `reset`, `getErrors`; composes holdings and summary components |
| [src/pages/components/HoldingsTableComponent.js](./src/pages/components/HoldingsTableComponent.js) | Table locators, loading/editing/removing rows, and input/output reads; `readTable` reads all rows in one browser round-trip |
| [src/pages/components/SummaryComponent.js](./src/pages/components/SummaryComponent.js) | Summary locators and `getValues` for investable amount, totals, residual cash, and status |
| [src/fixtures/fixtures.js](./src/fixtures/fixtures.js) | Extends the playwright-bdd test fixture with `rebalancePage`; exports the configured test and `Given`, `When`, `Then`, `Before`, and `After` |

Import BDD step functions from the custom fixtures module, so steps receive
the same configured page-object fixture. `Before` and `After` are available
exports; there are currently no custom hook implementations.

### Step definitions

| File | What it implements |
|------|--------------------|
| [src/steps/common.steps.js](./src/steps/common.steps.js) | Opening the app, account input, env account loading, JSON portfolio loading, fractional mode, Calculate/Reset, and default-account checks |
| [src/steps/holdings.steps.js](./src/steps/holdings.steps.js) | Gherkin holdings tables, add/remove/edit actions, bulk updates, and holdings-table assertions |
| [src/steps/calculation.steps.js](./src/steps/calculation.steps.js) | Explicit trade expectations, oracle comparisons, HOLD checks, absence-of-output checks, and post-trade business-goal checks |
| [src/steps/summary.steps.js](./src/steps/summary.steps.js) | Explicit summary values and oracle-based summary assertions |
| [src/steps/validation.steps.js](./src/steps/validation.steps.js) | Expected validation-message assertions and verification that errors are hidden |

Trade checks use soft assertions to report several mismatches together, then
stop the scenario at that step if mismatches occurred. Other failed hard
assertions stop the current scenario immediately.

### Feature files

| File | Cases | Purpose |
|------|-------|---------|
| [features/01_rebalance_e2e.feature](./features/01_rebalance_e2e.feature) | E2E-01 to E2E-06 | Core rebalance, balanced account, vesting, rounding, fractional shares, and data-driven portfolios |
| [features/02_validation_e2e.feature](./features/02_validation_e2e.feature) | E2E-07 and E2E-08 | Reject invalid input, verify no trades, and demonstrate correction/recalculation |
| [features/03_portfolio_maintenance_e2e.feature](./features/03_portfolio_maintenance_e2e.feature) | E2E-09 and E2E-10 | Restructure holdings, recover from invalid totals, clear stale results, and reset |
| [features/04_boundary_values_e2e.feature](./features/04_boundary_values_e2e.feature) | E2E-11 and E2E-12 | Accepted and rejected boundary examples |

### Generated and installed directories

These are outputs, not places to write business tests:

| Location | Contents |
|----------|----------|
| `.features-gen` | Playwright tests generated from Gherkin by `bddgen` |
| `node_modules` | Installed npm dependencies |
| `test-results` | Per-test execution artifacts, including configured screenshots, videos, and traces |
| `reports\html-report` | Playwright HTML report |
| `reports\cucumber\cucumber-report.html` | Cucumber-style HTML report |
| `reports\cucumber\cucumber-report.json` | Cucumber JSON results |
| `reports\junit\results.xml` | JUnit results for CI integrations |

## 5. Configure environments

### Step 1 - Choose local, QA, or UAT

`TEST_ENV` selects `config/.env.<TEST_ENV>`. If unset, it selects `local`.
The loader checks that the selected file exists and fails explicitly if not.

| Environment | Local server | Default browsers | Important note |
|-------------|--------------|------------------|----------------|
| local | Started automatically | chromium,firefox,webkit | Works with the bundled reference app |
| qa | Not started | chromium,firefox,webkit | Replace the placeholder URL with a real deployment URL |
| uat | Not started | chromium,firefox,webkit,edge | Replace the URL and ensure Edge is installed, or override browsers |

### Step 2 - Understand configuration precedence

1. Variables already set in your terminal or CI take precedence.
2. The selected environment file supplies values not already set.
3. Loader defaults apply when a value is missing or empty.

`ENV_NAME` is a descriptive exported value; **`TEST_ENV` chooses the file**.
The root `.env` file is not read by this loader.

### Step 3 - Know the settings

| Variable | Meaning |
|----------|---------|
| `TEST_ENV` | File selector, normally set in the shell or via `cross-env` |
| `ENV_NAME` | Environment label exported by the loader |
| `BASE_URL` | URL used by page navigation and the local server readiness check |
| `START_LOCAL_SERVER` | `true` enables Playwright's local web-server lifecycle; `false` requires an already deployed app |
| `APP_PORT` | Port passed to the reference server; keep it consistent with local `BASE_URL` |
| `BROWSERS` | Comma-separated supported browser project keys |
| `HEADLESS` | `true` for invisible browsers; `false` for visible execution |
| `WORKERS` | Parallel worker count, e.g. `2`, or percentage of CPU cores, e.g. `50%` |
| `RETRIES` | Local retry count; CI enforces at least one retry |
| `TEST_TIMEOUT` | Entire-test timeout in milliseconds |
| `EXPECT_TIMEOUT` | Timeout for retrying Playwright assertions in milliseconds |
| `ACTION_TIMEOUT` | Timeout for browser actions in milliseconds |
| `SCREENSHOT` | `off`, `on`, or `only-on-failure` |
| `VIDEO` | `off`, `on`, `retain-on-failure`, or `on-first-retry` |
| `TRACE` | Common modes: `off`, `on`, `retain-on-failure`, or `on-first-retry` |
| `TAGS` | Optional Cucumber tag expression applied during generation |
| `ACCOUNT_NAME`, `TOTAL_ASSET`, `VESTED_PERCENT` | Values entered only by the explicit environment-account step |

**Account variables do not reset the application or rewrite every scenario.**
Some scenarios deliberately use app defaults or hard-coded data. E2E-01's
expected outputs assume total asset 100000 and vested 100; changing those
environment inputs alone will make its expectations inconsistent.

### Step 4 - Run a remote environment

After updating the URL and checking the deployed app is compatible:

```powershell
npm run test:qa
npm run test:uat
```

Or override settings for a single invocation without editing files:

```powershell
npx cross-env TEST_ENV=qa BASE_URL=https://your-qa-host BROWSERS=chromium npm run test:smoke
```

The remote app must expose the same UI/test-ID contract and expected default
portfolio, or the POM and scenario setup must be adapted. Changing a URL alone
does not make this framework compatible with an unrelated application.

Do not put passwords, tokens, or private credentials in the committed
environment files. Supply secrets through approved shell/CI secret variables.
The three environment files are tracked despite their dot-prefixed names.

## 6. Select suites, priorities, and browsers

### Available commands

Counts below are **per selected browser** and assume no extra `TAGS` filter.

| Command | Selection |
|---------|-----------|
| `npm test` | All 42 expanded tests |
| `npm run test:smoke` | 2 tests: E2E-01 and E2E-07 |
| `npm run test:sanity` | 5 tests: E2E-01, 02, 03, 07, and 09 |
| `npm run test:regression` | All 42 tests |
| `npm run test:e2e` | All 42 tests; every feature has the E2E tag |
| `npm run test:bva` | 23 examples from E2E-11 and E2E-12 |
| `npm run test:p1` | 4 critical-priority tests |
| `npm run test:p2` | 36 high-priority tests |
| `npm run test:p3` | 2 low-priority tests |
| `npm run test:smoke:p1` | Intersection of smoke and P1: 2 tests |
| `npm run test:tags` | Same generation/run sequence as `npm test`; supply a `TAGS` expression |
| `npm run test:chromium` | All tests on Chromium, if it is included in configured `BROWSERS` |
| `npm run test:firefox` | All tests on Firefox, if configured |
| `npm run test:webkit` | All tests on WebKit, if configured |
| `npm run test:cross-browser` | All tests with chromium,firefox,webkit explicitly selected |
| `npm run test:headed` | Visible browsers, one worker |
| `npm run test:qa` / `npm run test:uat` | All tests using the chosen remote environment |
| `npm run bddgen` | Generate tests without executing them |
| `npm run app` | Run the reference server manually |
| `npm run report` | Open the latest Playwright HTML report |
| `npm run install:browsers` | Install Playwright browsers and required system dependencies |

### Tag meanings

| Tag | Purpose |
|-----|---------|
| `@smoke` | Fast build-verification journeys |
| `@sanity` | Core functionality to check after a change |
| `@regression` | Full currently implemented suite |
| `@e2e` | Browser-driven end-to-end UI journey |
| `@bva` | Selected boundary value analysis examples |
| `@P1` / `@P2` / `@P3` | Critical / high / low priority |
| `@E2E-01` through `@E2E-12` | Traceable case IDs |

Tags on a `Feature` are inherited by its scenarios. An outline's tags apply to
all of its example rows. Smoke and sanity are overlapping subsets of regression.

### Choose custom combinations

```powershell
npx cross-env TAGS="@smoke and @P1" npm run test:tags
npx cross-env TAGS="@sanity and not @P3" npm test
npx cross-env TAGS="@E2E-01 or @E2E-09" npm test
npx cross-env BROWSERS=chromium TAGS="@bva" npm test
```

There are two filtering stages:

- **`TAGS`** is a Cucumber expression applied by `bddgen` before tests exist.
- **`--grep`** is a Playwright regular expression applied to generated tests.

If both are present, only tests surviving **both** filters run. A grep cannot
recover a scenario excluded during generation. Clear restrictive shell `TAGS`
settings before returning to the full suite.

### Select browsers

Supported project keys:

| Key | What runs |
|-----|-----------|
| `chromium` | Playwright-managed Chromium |
| `firefox` | Playwright-managed Firefox |
| `webkit` | Playwright-managed WebKit; not the installed Safari application |
| `chrome` | Installed Google Chrome via the `chrome` channel |
| `edge` | Installed Microsoft Edge via the `msedge` channel |
| `mobile-chrome` | Chromium with Pixel 7 device emulation |
| `mobile-safari` | WebKit with iPhone 14 device emulation |

Mobile projects emulate viewport/device behavior; they are not real-device tests.
Chrome and Edge require their branded browsers to be installed.

```powershell
npx cross-env BROWSERS=chromium,firefox npm run test:smoke
npx cross-env BROWSERS=edge npm run test:smoke
npx cross-env BROWSERS=mobile-chrome,mobile-safari npm run test:smoke
```

`--project` chooses from projects that `BROWSERS` already enabled. It does not
create a missing browser project.

### Parallel execution

[playwright.config.js](./playwright.config.js) enables `fullyParallel`.
Each test receives its own browser context/page and POM instance; steps within
one scenario remain sequential. Local workers are controlled by `WORKERS`.

```powershell
npx cross-env WORKERS=2 npm run test:regression
npm run test:smoke -- --project=chromium --workers=1
```

For the default three browsers, full regression expands to **126 executions**
(42 x 3). The local app is stateless, which supports isolation. A future
shared backend will also need isolated account/test data; browser isolation
alone does not prevent server-side data conflicts.

## 7. Understand the existing test coverage

There are **12 named scenarios/scenario outlines**, which expand to **42 tests
per browser** because every `Examples` row becomes a separate test.

| ID | Journey | Tests per browser | Suites | Priority |
|----|---------|------------------:|--------|----------|
| E2E-01 | Default assessment rebalance and summary | 1 | Smoke, Sanity, Regression | P1 |
| E2E-02 | Balanced holdings produce HOLD/0 | 1 | Sanity, Regression | P1 |
| E2E-03 | Rebalance only the 50% vested portion | 1 | Sanity, Regression | P2 |
| E2E-04 | Whole-share rounding for three account sizes | 3 | Regression | P2 |
| E2E-05 | Fractional share quantities | 1 | Regression | P3 |
| E2E-06 | Four named portfolios, oracle and post-trade checks | 4 | Regression | P2 |
| E2E-07 | Invalid target total, correction, successful recalculation | 1 | Smoke, Sanity, Regression | P1 |
| E2E-08 | Five invalid-input examples | 5 | Regression | P2 |
| E2E-09 | Remove HD, add TSLA, correct totals, and rebalance | 1 | Sanity, Regression | P1 |
| E2E-10 | Clear stale output and reset defaults | 1 | Regression | P3 |
| E2E-11 | Accepted boundary values | 11 | Regression, BVA | P2 |
| E2E-12 | Rejected boundary values | 12 | Regression, BVA | P2 |

All cases also inherit `@e2e`. Manual instructions and expected results are in
[docs/TEST_CASES.md](./docs/TEST_CASES.md).

### How correctness is checked

1. **Explicit expected values:** the assessment example and selected boundary
   cases assert known actions, quantities, and summary values.
2. **Independent calculation:** the oracle computes expected results from
   account and holdings inputs, not from the displayed trade results.
3. **Business-goal simulation:** application-produced actions/share quantities
   are applied mathematically to the starting portfolio and checked against targets.
4. **Validation and state checks:** rejected input produces no trade output;
   correction permits recalculation; edits clear stale results; reset restores defaults.

### Boundary coverage and limitations

Covered examples include:

- A trade worth exactly one share versus just under one share.
- Positive 0.01 asset/price values and zero/negative rejection examples.
- Vested 0, 0.01, 99.99, 100, and values above 100.
- Target/current 0% and 100% endpoints, and -0.01/100.01 invalid values.
- Target/current totals 99.99 and 100.01.
- Opposite 0.01-percentage-point variances.

These are selected business boundaries, not an exhaustive numeric-input suite.
Values labelled "smallest" in the feature examples mean the selected two-decimal
test values; the implementation does not enforce a universal 0.01 minimum.
The suite does not currently test every point around the `0.0001` tolerance,
every invalid-text/blank-input permutation, empty holdings, or blank symbols.
No authentication, persistence, API, or actual order-execution coverage is present.

## 8. Read reports and debug failures

### Step 1 - Inspect the terminal

Identify the failed browser, scenario ID/example row, and first failed step.
Do not assume a retry-passing test is healthy: inspect flaky results as well.

### Step 2 - Open the Playwright report

```powershell
npm run report
```

The HTML report includes step details and available attachments. The Cucumber
HTML report gives a feature/scenario-oriented view. JUnit XML is for CI tools.
These output directories are created by execution; they may not exist before
the first run. Later runs normally replace the report at the same location.

### Step 3 - Inspect failure evidence

Local defaults capture screenshots on failure and retain failure videos/traces.
QA/UAT defaults use `TRACE=on-first-retry`, so a trace is not necessarily
recorded on the first attempt.

To open an actual trace file:

```powershell
npx playwright show-trace "C:\full\path\to\trace.zip"
```

Replace the example path with the trace attached to your failed test.

### Step 4 - Reproduce a single case visibly

```powershell
npx cross-env BROWSERS=chromium HEADLESS=false TAGS="@E2E-07" npm test -- --workers=1
```

For Playwright Inspector:

```powershell
npx cross-env BROWSERS=chromium TAGS="@E2E-07" npm test -- --debug
```

An outline ID selects all its example rows. To narrow an outline further, use
`--grep` with a distinctive generated example name.

## 9. Add or maintain a test

### Step 1 - Define the business requirement

Record inputs, expected behavior, priority, and intended suite. Read
[docs/TEST_CASES.md](./docs/TEST_CASES.md) and the existing features first to
avoid duplicating an already covered journey.

### Step 2 - Reuse existing Gherkin steps

For example, a new case could be added to
[features/01_rebalance_e2e.feature](./features/01_rebalance_e2e.feature):

```gherkin
  @P2 @E2E-13
  Scenario: A quarter-vested account calculates whole-share trades
    When I enter vested percentage "25"
    And I click Calculate
    Then no validation errors should be displayed
    And "IBM" should show action "BUY" with "16" shares
    And "ORCL" should show action "SELL" with "11" shares
    And the trade summary should match the expected rebalance calculation
```

This is an **illustration, not an existing test**. It relies on that feature's
existing `Background` opening the app, and inherits its regression/E2E tags.
It needs no new step definitions or selectors.

Use a `Scenario Outline` with `Examples` when the same flow needs multiple
inputs. Use Gherkin data tables for holdings or multi-field expected results.
In JavaScript, `dataTable.hashes()` gives row objects and `rowsHash()` gives
key/value pairs.

### Step 3 - Add JSON data when a reusable portfolio is needed

Add a unique key to [test-data/portfolios.json](./test-data/portfolios.json).
Use this shape:

```json
{
  "description": "Why this dataset exists",
  "totalAsset": 100000,
  "vested": 100,
  "holdings": [
    { "symbol": "IBM", "target": 60, "current": 40, "price": 150 },
    { "symbol": "ORCL", "target": 40, "current": 60, "price": 220 }
  ]
}
```

Load it with `Given I load the "yourDatasetKey" portfolio from test data`.
The step sets asset/vesting and replaces all holdings through the UI.
Keep allocation totals valid unless invalid totals are the intended test.

### Step 4 - Add a step only if no suitable one exists

Put it in the relevant step file. Follow the existing fixture-import pattern:

```javascript
const { Then } = require('../fixtures/fixtures');
```

Use the supplied `rebalancePage` fixture. Keep selectors and browser actions
in page/component classes; keep business assertions in steps. Avoid duplicate
step text, arbitrary sleeps, and direct dependencies between scenarios.

### Step 5 - Extend the POM when the UI needs a new interaction

- Account/form behavior belongs in
  [src/pages/RebalancePage.js](./src/pages/RebalancePage.js).
- Holdings behavior belongs in
  [src/pages/components/HoldingsTableComponent.js](./src/pages/components/HoldingsTableComponent.js).
- Summary behavior belongs in
  [src/pages/components/SummaryComponent.js](./src/pages/components/SummaryComponent.js).

Reuse stable `data-testid` locators and existing methods. For a deployed app
with different selectors, adapt the POM rather than every feature.

### Step 6 - Generate and check test discovery

```powershell
npm run bddgen
npx playwright test --list --project=chromium
```

Undefined or ambiguous step definitions must be resolved before execution.
Never patch generated tests as a workaround.

### Step 7 - Run targeted tests, then affected suites

If you implemented the illustrative E2E-13:

```powershell
npx cross-env BROWSERS=chromium TAGS="@E2E-13" npm test
```

Then, with no restrictive shell `TAGS` value:

```powershell
npm run test:sanity
npm run test:cross-browser
```

Choose the smallest meaningful validation first; run full cross-browser
regression when shared calculation, fixture, or component changes affect it.

### Step 8 - Update traceability and documentation

Add the manual case, update scenario counts and tags in this guide, and
document any changed business assumptions. If adding a new browser or
environment, update configuration and CI as well.

## 10. Understand the CI pipeline

The workflow is
[.github/workflows/playwright-bdd.yml](./.github/workflows/playwright-bdd.yml).
It must be at the **Git repository root** under `.github/workflows` for GitHub
Actions discovery. Its commands also assume the package is at the repository
root; if retaining a nested project, configure checkout paths/working
directories and the npm cache dependency path appropriately.

### Automatic triggers

| Event | Suite |
|-------|-------|
| Push to `main` or `develop` | Smoke |
| Pull request targeting `main` | Sanity |
| Nightly at 02:00 UTC | Regression |
| Manual workflow dispatch | User-selected suite |

### Job flow

1. Check out the repository.
2. Set up Node.js 20 with npm caching.
3. Install locked dependencies with `npm ci`.
4. Check whether the matrix browser was requested.
5. Install that browser and its system dependencies.
6. Generate the BDD tests.
7. Execute the selected tag on the browser and shard.
8. Upload reports, upload failure evidence, and publish JUnit results.

The matrix is **3 browsers x 2 shards = 6 jobs**. Each job selects one browser
and runs either `--shard=1/2` or `--shard=2/2`. Workers provide parallelism
inside each job; shards divide tests between jobs. CI requires at least one
retry and rejects focused `test.only` tests.

Reports are uploaded per browser/shard; the current workflow does not merge
them into one combined HTML report. Report retention is 14 days; failure
artifact retention is 7 days. A newer run on the same workflow/ref cancels
the previous in-progress run.

### Manually run the workflow

1. Push the framework into the correct repository layout.
2. Open GitHub **Actions** and select **Portfolio Rebalancer BDD Tests**.
3. Choose **Run workflow**.
4. Select suite, environment, and a comma-separated browser list.
5. Run and inspect jobs, JUnit results, and uploaded artifacts.

The current suite dropdown offers smoke, sanity, regression, e2e, P1, P2,
and P3. It does **not** offer BVA separately; regression includes BVA tests.
The browser matrix supports only chromium, firefox, and webkit; manual input
can select a subset, not add Chrome/Edge/mobile jobs.

For QA/UAT, configure a real URL and compatible deployed app first.
The workflow shows a commented example of a `BASE_URL` secret; that example
does not activate secret injection until it is wired into the job environment.
The pipeline's browser variable overrides each environment file's browser list.

## 11. Troubleshooting

| Problem | Check or fix |
|---------|--------------|
| `npm` or `npx` fails on Windows | Check Node installation/PATH and shell execution policy. Use the direct CLI alternatives below if the wrappers are broken |
| Browser executable missing | Run `npx playwright install chromium firefox webkit` for managed browsers; install branded Chrome/Edge if selected |
| Unknown project/browser | Check spelling in `BROWSERS`; `--project` must refer to an enabled project |
| No tests found | Check `TAGS`, `--grep`, case-sensitive priority tags, and browser selection; regenerate after changing filters |
| Undefined or ambiguous BDD step | Check exact step text/parameters and duplicate definitions; import from the custom fixtures module |
| Environment file not found | Check `TEST_ENV` and the corresponding configuration file |
| QA/UAT navigation fails | Replace placeholder URLs, verify connectivity and deployment, and keep local server startup disabled |
| App readiness timeout or port conflict | Check `BASE_URL` and `APP_PORT` match; verify what is listening on the port rather than stopping unrelated processes |
| Wrong app reused locally | Non-CI runs allow reuse of a server responding at `BASE_URL`; confirm it is the intended reference app |
| Selector failure on remote deployment | Verify the expected `data-testid` contract and default holdings; adapt the POM/setup |
| E2E-01 fails after env data changes | Its explicit outputs expect total asset 100000 and vested 100; changing inputs requires compatible expectations |
| Generated test looks incorrect | Fix feature/step source and rerun `bddgen`; do not edit `.features-gen` |
| No trace attached | Check capture mode; `on-first-retry` requires a retry and does not capture the initial attempt |

### Windows fallback when npm/npx wrappers are broken

On the assessment machine, the CLI wrappers were unreliable. If Node.js is
installed at the path below, npm can be called directly:

```powershell
node "C:\Program Files\nodejs\node_modules\npm\bin\npm-cli.js" ci
```

With dependencies installed, bypass wrappers for generation and execution:

```powershell
node node_modules\playwright-bdd\dist\cli\index.js
if ($LASTEXITCODE -eq 0) {
  node node_modules\@playwright\test\cli.js test --project=chromium --grep "@smoke"
}
```

Install a browser or open the report directly:

```powershell
node node_modules\@playwright\test\cli.js install chromium
node node_modules\@playwright\test\cli.js show-report reports\html-report
```

Adjust the npm CLI path if your Node.js installation differs. These fallbacks
do not replace fixing the machine's PATH/wrappers for everyday npm scripts.

## 12. New joiner checklist and presentation flow

### First-day checklist

- [ ] Read the business assumptions and default expected result.
- [ ] Install dependencies and at least Chromium.
- [ ] Review the local environment settings.
- [ ] Run the Chromium smoke suite and open its report.
- [ ] Trace one Gherkin step through fixtures, POM, app, and assertions.
- [ ] Read the feature files and matching manual cases.
- [ ] Run one tagged validation case and the BVA suite.
- [ ] Understand where generated files and failure evidence live.
- [ ] Confirm real deployment URLs and browser availability before remote runs.
- [ ] Add tests through feature/step/POM source, not generated files.


