/*
 * Portfolio Rebalancer - application under test.
 * Business rules (see README "Assumptions"):
 *   investable      = totalAsset * vested% / 100
 *   variance        = current% - target%   (negative => BUY, positive => SELL, zero => HOLD)
 *   tradeValue      = |variance| / 100 * investable
 *   shares          = tradeValue / unitPrice, rounded DOWN to whole shares unless fractional is enabled
 */
(function () {
  const DEFAULT_HOLDINGS = [
    { symbol: 'IBM', target: 20, current: 10, price: 150 },
    { symbol: 'MSFT', target: 20, current: 20, price: 90 },
    { symbol: 'ORCL', target: 20, current: 30, price: 220 },
    { symbol: 'AAPL', target: 20, current: 20, price: 450 },
    { symbol: 'HD', target: 20, current: 20, price: 70 },
  ];
  const DEFAULT_ACCOUNT = { name: 'ABC', totalAsset: '100000', vested: '100' };
  const TOLERANCE = 0.0001;

  const $ = (id) => document.getElementById(id);
  const body = $('holdings-body');

  const round = (n, dp) => Math.round(n * 10 ** dp) / 10 ** dp;
  const fmt = (n) => round(n, 2).toFixed(2);
  const isNumeric = (v) => String(v).trim() !== '' && !isNaN(Number(v));

  function addRow(h = { symbol: '', target: '', current: '', price: '' }) {
    const tr = document.createElement('tr');
    tr.className = 'holding-row';
    tr.innerHTML = `
      <td><input data-testid="symbol" type="text" value="${h.symbol}" /></td>
      <td><input data-testid="target" type="text" value="${h.target}" /></td>
      <td><input data-testid="current" type="text" value="${h.current}" /></td>
      <td data-testid="variance"></td>
      <td><input data-testid="price" type="text" value="${h.price}" /></td>
      <td data-testid="action"></td>
      <td data-testid="shares"></td>
      <td data-testid="trade-value"></td>
      <td><button data-testid="remove-security" type="button">Remove</button></td>`;
    tr.querySelector('[data-testid="remove-security"]').addEventListener('click', () => {
      tr.remove();
      onInputChange();
    });
    tr.querySelectorAll('input').forEach((i) => i.addEventListener('input', onInputChange));
    body.appendChild(tr);
    onInputChange();
  }

  function readRows() {
    return [...body.querySelectorAll('tr.holding-row')].map((tr) => ({
      tr,
      symbol: tr.querySelector('[data-testid="symbol"]').value.trim().toUpperCase(),
      target: tr.querySelector('[data-testid="target"]').value,
      current: tr.querySelector('[data-testid="current"]').value,
      price: tr.querySelector('[data-testid="price"]').value,
    }));
  }

  function clearOutput() {
    body.querySelectorAll('[data-testid="action"],[data-testid="shares"],[data-testid="trade-value"]').forEach((c) => {
      c.textContent = '';
      c.className = '';
    });
    document.querySelector('[data-testid="summary"]').hidden = true;
  }

  function updateTotalsAndVariance() {
    let tTarget = 0;
    let tCurrent = 0;
    readRows().forEach((r) => {
      const ok = isNumeric(r.target) && isNumeric(r.current);
      r.tr.querySelector('[data-testid="variance"]').textContent = ok
        ? String(round(Number(r.current) - Number(r.target), 4))
        : '';
      if (isNumeric(r.target)) tTarget += Number(r.target);
      if (isNumeric(r.current)) tCurrent += Number(r.current);
    });
    document.querySelector('[data-testid="total-target"]').textContent = String(round(tTarget, 4));
    document.querySelector('[data-testid="total-current"]').textContent = String(round(tCurrent, 4));
  }

  function onInputChange() {
    updateTotalsAndVariance();
    clearOutput();
  }

  function showErrors(errors) {
    const box = $('error-messages');
    box.innerHTML = errors.map((e) => `<div data-testid="error-item">${e}</div>`).join('');
    box.hidden = errors.length === 0;
  }

  function validate(rows, totalAsset, vested) {
    const errors = [];
    if (!isNumeric(totalAsset) || Number(totalAsset) <= 0) errors.push('Total asset must be a positive number');
    if (!isNumeric(vested) || Number(vested) <= 0 || Number(vested) > 100)
      errors.push('Vested percentage must be greater than 0 and at most 100');
    if (rows.length === 0) {
      errors.push('At least one security is required');
      return errors;
    }
    const seen = new Set();
    rows.forEach((r, idx) => {
      const name = r.symbol || `row ${idx + 1}`;
      if (!r.symbol) errors.push(`Security symbol is required for row ${idx + 1}`);
      else if (seen.has(r.symbol)) errors.push(`Duplicate security: ${r.symbol}`);
      seen.add(r.symbol);
      if (!isNumeric(r.target) || Number(r.target) < 0 || Number(r.target) > 100)
        errors.push(`Target % for ${name} must be between 0 and 100`);
      if (!isNumeric(r.current) || Number(r.current) < 0 || Number(r.current) > 100)
        errors.push(`Current % for ${name} must be between 0 and 100`);
      if (!isNumeric(r.price) || Number(r.price) <= 0) errors.push(`Unit price for ${name} must be greater than 0`);
    });
    if (errors.length) return errors;
    const sumT = rows.reduce((s, r) => s + Number(r.target), 0);
    const sumC = rows.reduce((s, r) => s + Number(r.current), 0);
    if (Math.abs(sumT - 100) > TOLERANCE) errors.push(`Total target % must equal 100 (currently ${round(sumT, 4)})`);
    if (Math.abs(sumC - 100) > TOLERANCE) errors.push(`Total current % must equal 100 (currently ${round(sumC, 4)})`);
    return errors;
  }

  function calculate() {
    clearOutput();
    const rows = readRows();
    const totalAsset = $('total-asset').value;
    const vested = $('vested-percent').value;
    const errors = validate(rows, totalAsset, vested);
    showErrors(errors);
    if (errors.length) return;

    const fractional = $('fractional-toggle').checked;
    const investable = (Number(totalAsset) * Number(vested)) / 100;
    let totalBuy = 0;
    let totalSell = 0;

    rows.forEach((r) => {
      const variance = Number(r.current) - Number(r.target);
      const action = Math.abs(variance) < TOLERANCE ? 'HOLD' : variance < 0 ? 'BUY' : 'SELL';
      const rawShares = action === 'HOLD' ? 0 : ((Math.abs(variance) / 100) * investable) / Number(r.price);
      // Small epsilon prevents float noise (e.g. 9.9999999) from flooring away a whole share.
      const shares = fractional ? round(rawShares, 4) : Math.floor(rawShares + 1e-9);
      const value = shares * Number(r.price);
      if (action === 'BUY') totalBuy += value;
      if (action === 'SELL') totalSell += value;

      const actionCell = r.tr.querySelector('[data-testid="action"]');
      actionCell.textContent = action;
      actionCell.className = action;
      r.tr.querySelector('[data-testid="shares"]').textContent = String(shares);
      r.tr.querySelector('[data-testid="trade-value"]').textContent = fmt(value);
    });

    $('error-messages').hidden = true;
    document.querySelector('[data-testid="investable-asset"]').textContent = fmt(investable);
    document.querySelector('[data-testid="total-buy"]').textContent = fmt(totalBuy);
    document.querySelector('[data-testid="total-sell"]').textContent = fmt(totalSell);
    document.querySelector('[data-testid="residual-cash"]').textContent = fmt(totalSell - totalBuy);
    document.querySelector('[data-testid="status-message"]').textContent =
      totalBuy === 0 && totalSell === 0 ? 'Portfolio is already balanced' : 'Rebalance trades calculated';
    document.querySelector('[data-testid="summary"]').hidden = false;
  }

  function reset() {
    body.innerHTML = '';
    $('account-name').value = DEFAULT_ACCOUNT.name;
    $('total-asset').value = DEFAULT_ACCOUNT.totalAsset;
    $('vested-percent').value = DEFAULT_ACCOUNT.vested;
    $('fractional-toggle').checked = false;
    showErrors([]);
    DEFAULT_HOLDINGS.forEach((h) => addRow(h));
  }

  $('add-security').addEventListener('click', () => addRow());
  $('calculate').addEventListener('click', calculate);
  $('reset').addEventListener('click', reset);
  ['total-asset', 'vested-percent', 'fractional-toggle'].forEach((id) => $(id).addEventListener('input', clearOutput));
  $('fractional-toggle').addEventListener('change', clearOutput);

  reset();
})();
