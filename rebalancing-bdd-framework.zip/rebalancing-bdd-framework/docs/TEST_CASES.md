# End-to-End Test Cases – Portfolio Rebalancer

**Preconditions (all cases):** the application is open with the defaults: account **ABC**, total asset
**$100,000**, **100%** vested, whole-share mode, and the holdings below.

| Security | Target % | Current % | Variance | Unit price |
|----------|---------:|----------:|---------:|-----------:|
| IBM  | 20 | 10 | -10 | 150 |
| MSFT | 20 | 20 |   0 |  90 |
| ORCL | 20 | 30 | +10 | 220 |
| AAPL | 20 | 20 |   0 | 450 |
| HD   | 20 | 20 |   0 |  70 |

**Formula:** shares = (|current% − target%| / 100 × total asset × vested%) / unit price, rounded **down**.
Negative variance = BUY, positive = SELL, zero = HOLD.

Suite: **SM** = Smoke, **SA** = Sanity, **RG** = Regression. Priority: **P1** critical, **P2** high, **P3** low.

---

### E2E-01 – Rebalance account ABC from the specification to zero target variance  (SM, SA, RG · P1)
| # | Step | Expected result |
|---|------|-----------------|
| 1 | Open the app and enter the account details from the env file | Account ABC, $100,000, 100% vested |
| 2 | Review the holdings table | Values and variance match the precondition table |
| 3 | Click **Calculate** | No errors |
| 4 | Check the trade output | IBM **BUY 66** ($9,900) · ORCL **SELL 45** ($9,900) · MSFT, AAPL, HD HOLD 0 |
| 5 | Check the summary | Investable $100,000.00 · Buy $9,900.00 · Sell $9,900.00 · Residual $0.00 · "Rebalance trades calculated" |
| 6 | Apply the trades to the portfolio | Every security ends within one share's price of its 20% target |

### E2E-02 – An already balanced portfolio needs no trades  (SA, RG · P1)
| # | Step | Expected result |
|---|------|-----------------|
| 1 | Enter IBM, MSFT, ORCL, AAPL at 25% target / 25% current | Totals are 100 / 100 |
| 2 | Click **Calculate** | Every security HOLD 0 |
| 3 | Check the summary | Buy $0.00 · Sell $0.00 · "Portfolio is already balanced" |

### E2E-03 – Only the vested part of the account is rebalanced  (SA, RG · P2)
| # | Step | Expected result |
|---|------|-----------------|
| 1 | Set vested % to **50** and click **Calculate** | Investable asset $50,000 |
| 2 | Check the trade output | IBM BUY 33 ($4,950) · ORCL SELL 22 ($4,840) |
| 3 | Check the summary | Buy $4,950.00 · Sell $4,840.00 · Residual **−$110.00** (cash needed because of rounding) |

### E2E-04 – Whole-share rounding for different account sizes  (RG · P2)
| Total asset | IBM BUY | ORCL SELL | Why it matters |
|------------:|--------:|----------:|----------------|
| 250,000 | 166 | 113 | Scales with account size |
| 1,500   | 1   | 0   | ORCL trade ($150) is worth less than 1 share |
| 1,000   | 0   | 0   | Both trades are worth less than 1 share |

### E2E-05 – Fractional shares bring the account to exact target values  (RG · P3)
| # | Step | Expected result |
|---|------|-----------------|
| 1 | Turn on **Allow fractional shares** and click **Calculate** | IBM BUY 66.6667 · ORCL SELL 45.4545 |
| 2 | Apply the trades | Every security is at its target value (within rounding) |

### E2E-06 – Data-driven rebalance of portfolios from test data  (RG · P2)
For each portfolio in `test-data/portfolios.json` (**heavyRebalance**, **newAndExitPositions**,
**decimalPortfolio**, **highValueAccount**): load it, click **Calculate**, then check:
* there are no errors
* each security's action, shares and trade value match the independent calculator
* the summary totals match the calculator
* after the trades, every security is within one share of its target

### E2E-07 – Target that does not total 100% is rejected, corrected and rebalanced  (SM, SA, RG · P1)
| # | Step | Expected result |
|---|------|-----------------|
| 1 | Set IBM target to **10** and click **Calculate** | Error "Total target % must equal 100 (currently 90)"; no trades, no summary |
| 2 | Set IBM target back to **20** and click **Calculate** | Error clears; IBM BUY 66, ORCL SELL 45 |

### E2E-08 – Invalid input is rejected  (RG · P2)
| Case | Input | Expected error (no trades shown) |
|------|-------|----------------------------------|
| Current total not 100 | IBM current = 20 | Total current % must equal 100 (currently 110) |
| Zero total asset | Total asset = 0 | Total asset must be a positive number |
| Vested above 100% | Vested = 101 | Vested percentage must be greater than 0 and at most 100 |
| Zero unit price | IBM price = 0 | Unit price for IBM must be greater than 0 |
| Duplicate security | Rename MSFT to IBM | Duplicate security: IBM |

### E2E-09 – Restructure the portfolio: exit HD, add TSLA, fix an error and rebalance  (SA, RG · P1)
| # | Step | Expected result |
|---|------|-----------------|
| 1 | Set total asset to **$200,000** | – |
| 2 | Remove **HD**; add **TSLA** (target 20, current 0, price 245.50) | 5 securities |
| 3 | Set targets/currents: IBM 25/30, MSFT 15/20, ORCL 20/30, AAPL 20/30, then **Calculate** | Error "Total current % must equal 100 (currently 110)" |
| 4 | Fix AAPL current to **20** and click **Calculate** | No errors |
| 5 | Check the trade output | IBM SELL 66 · MSFT SELL 111 · ORCL SELL 90 · AAPL HOLD 0 · TSLA BUY 162; matches the calculator |
| 6 | Apply the trades | Every security within one share of its target |

### E2E-10 – Editing clears old results and Reset restores the defaults  (RG · P3)
| # | Step | Expected result |
|---|------|-----------------|
| 1 | Click **Calculate** | IBM BUY 66 |
| 2 | Change IBM price to 100 | Old results and summary are cleared (no stale output) |
| 3 | Click **Reset** | Account ABC / 100000 / 100%, fractional off, default holdings restored |
| 4 | Click **Calculate** | IBM BUY 66 again (same result every time) |

## Boundary value analysis (`@bva`)

Limits: total asset > 0 · 0 < vested % ≤ 100 · unit price > 0 · 0 ≤ target % / current % ≤ 100 · target and current must each total exactly 100 · a trade worth less than one share rounds down to 0.
Each case starts from the default spec portfolio, changes **one** value, then clicks **Calculate**.

### E2E-11 – Boundary values are accepted  (RG · BVA · P2)
| # | Boundary | Input | Expected result |
|---|----------|-------|-----------------|
| 1 | Trade worth exactly one share | Total asset 1500 | No error · IBM BUY 1 |
| 2 | Trade worth just under one share | Total asset 1499 | No error · IBM BUY 0 |
| 3 | Smallest total asset | Total asset 0.01 | No error · IBM BUY 0 |
| 4 | Smallest vested % | Vested 0.01 | No error · IBM BUY 0 |
| 5 | Vested just under maximum | Vested 99.99 | No error · IBM BUY 66 |
| 6 | Vested at maximum | Vested 100 | No error · ORCL SELL 45 |
| 7 | Smallest unit price | IBM price 0.01 | No error · IBM BUY 1,000,000 |
| 8 | Target 100% / current 0% | `boundaryAllocation` portfolio | No error · IBM BUY 666 |
| 9 | Target 0% / current 100% | `boundaryAllocation` portfolio | No error · ORCL SELL 454 |
| 10 | Smallest variance −0.01% | `minimalVariance` portfolio | No error · IBM BUY 10 |
| 11 | Smallest variance +0.01% | `minimalVariance` portfolio | No error · MSFT SELL 10 |

### E2E-12 – Boundary values are rejected  (RG · BVA · P2)
| # | Boundary | Input | Expected error (no trade output shown) |
|---|----------|-------|----------------------------------------|
| 1 | Total asset just below 0 | Total asset −0.01 | Total asset must be a positive number |
| 2 | Vested at 0 | Vested 0 | Vested percentage must be greater than 0 and at most 100 |
| 3 | Vested just above 100 | Vested 100.01 | Vested percentage must be greater than 0 and at most 100 |
| 4 | Unit price just below 0 | IBM price −0.01 | Unit price for IBM must be greater than 0 |
| 5 | Target just above 100 | IBM target 100.01 | Target % for IBM must be between 0 and 100 |
| 6 | Target just below 0 | IBM target −0.01 | Target % for IBM must be between 0 and 100 |
| 7 | Current just above 100 | IBM current 100.01 | Current % for IBM must be between 0 and 100 |
| 8 | Current just below 0 | IBM current −0.01 | Current % for IBM must be between 0 and 100 |
| 9 | Target total just below 100 | IBM target 19.99 | Total target % must equal 100 (currently 99.99) |
| 10 | Target total just above 100 | IBM target 20.01 | Total target % must equal 100 (currently 100.01) |
| 11 | Current total just below 100 | IBM current 9.99 | Total current % must equal 100 (currently 99.99) |
| 12 | Current total just above 100 | IBM current 10.01 | Total current % must equal 100 (currently 100.01) |
