@regression @e2e
Feature: Portfolio rebalancing - end-to-end journeys
  As a portfolio manager
  I want the application to tell me how many shares to BUY or SELL for each security
  So that my account reaches zero target variance

  Formula: shares = (|current% - target%| / 100 x investable asset) / unit price, rounded down
           investable asset = total asset x vested%; negative variance = BUY, positive = SELL

  Background:
    Given I open the Portfolio Rebalancer application

  @smoke @sanity @P1 @E2E-01
  Scenario: Rebalance account ABC from the specification to zero target variance
    Given the account details from the environment are entered
    Then the holdings table should display:
      | symbol | target | current | variance | price |
      | IBM    | 20     | 10      | -10      | 150   |
      | MSFT   | 20     | 20      | 0        | 90    |
      | ORCL   | 20     | 30      | 10       | 220   |
      | AAPL   | 20     | 20      | 0        | 450   |
      | HD     | 20     | 20      | 0        | 70    |
    When I click Calculate
    Then no validation errors should be displayed
    And the trade output should be:
      | symbol | action | shares | tradeValue |
      | IBM    | BUY    | 66     | 9900.00    |
      | MSFT   | HOLD   | 0      | 0.00       |
      | ORCL   | SELL   | 45     | 9900.00    |
      | AAPL   | HOLD   | 0      | 0.00       |
      | HD     | HOLD   | 0      | 0.00       |
    And the trade summary should show:
      | investableAsset | 100000.00                   |
      | totalBuy        | 9900.00                     |
      | totalSell       | 9900.00                     |
      | residualCash    | 0.00                        |
      | statusMessage   | Rebalance trades calculated |
    And after applying the trades every security should be within one share of its target value

  @sanity @P1 @E2E-02
  Scenario: An already balanced portfolio needs no trades
    Given the account holds the following securities:
      | symbol | target | current | price |
      | IBM    | 25     | 25      | 150   |
      | MSFT   | 25     | 25      | 90    |
      | ORCL   | 25     | 25      | 220   |
      | AAPL   | 25     | 25      | 450   |
    When I click Calculate
    Then every security should show action "HOLD" with "0" shares
    And the trade summary should show:
      | totalBuy      | 0.00                          |
      | totalSell     | 0.00                          |
      | statusMessage | Portfolio is already balanced |

  @sanity @P2 @E2E-03
  Scenario: Only the vested part of the account is rebalanced
    When I enter vested percentage "50"
    And I click Calculate
    Then the trade output should be:
      | symbol | action | shares | tradeValue |
      | IBM    | BUY    | 33     | 4950.00    |
      | ORCL   | SELL   | 22     | 4840.00    |
    And the trade summary should show:
      | investableAsset | 50000.00 |
      | totalBuy        | 4950.00  |
      | totalSell       | 4840.00  |
      | residualCash    | -110.00  |

  @P2 @E2E-04
  Scenario Outline: Whole-share rounding for an account worth <totalAsset>
    When I enter total asset "<totalAsset>"
    And I click Calculate
    Then "IBM" should show action "BUY" with "<ibmShares>" shares
    And "ORCL" should show action "SELL" with "<orclShares>" shares

    Examples:
      | totalAsset | ibmShares | orclShares | note                              |
      | 250000     | 166       | 113        | larger account                    |
      | 1500       | 1         | 0          | ORCL trade worth less than 1 share |
      | 1000       | 0         | 0          | both trades worth less than 1 share |

  @P3 @E2E-05
  Scenario: Fractional shares bring the account to exact target values
    When I enable fractional shares
    And I click Calculate
    Then "IBM" should show action "BUY" with "66.6667" shares
    And "ORCL" should show action "SELL" with "45.4545" shares
    And after applying the trades every security should be within one share of its target value

  @P2 @E2E-06
  Scenario Outline: Data-driven rebalance of the "<portfolio>" portfolio
    Given I load the "<portfolio>" portfolio from test data
    When I click Calculate
    Then no validation errors should be displayed
    And the trade output should match the expected rebalance calculation
    And the trade summary should match the expected rebalance calculation
    And after applying the trades every security should be within one share of its target value

    Examples:
      | portfolio           |
      | heavyRebalance      |
      | newAndExitPositions |
      | decimalPortfolio    |
      | highValueAccount    |
