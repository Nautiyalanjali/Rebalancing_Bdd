@regression @e2e
Feature: Invalid input is rejected end to end
  Invalid input must show a clear error and produce no trades.
  Once the input is fixed, the calculation runs normally.

  Background:
    Given I open the Portfolio Rebalancer application

  @smoke @sanity @P1 @E2E-07
  Scenario: Target allocation that does not total 100% is rejected, corrected and rebalanced
    When I set the "target" of security "IBM" to "10"
    And I click Calculate
    Then I should see the error "Total target % must equal 100 (currently 90)"
    And no trade output should be displayed
    When I set the "target" of security "IBM" to "20"
    And I click Calculate
    Then no validation errors should be displayed
    And "IBM" should show action "BUY" with "66" shares
    And "ORCL" should show action "SELL" with "45" shares

  @P2 @E2E-08
  Scenario Outline: Invalid input is rejected - <case>
    When <action>
    And I click Calculate
    Then I should see the error "<error>"
    And no trade output should be displayed

    Examples:
      | case                  | action                                         | error                                                    |
      | current total not 100 | I set the "current" of security "IBM" to "20"  | Total current % must equal 100 (currently 110)           |
      | zero total asset      | I enter total asset "0"                        | Total asset must be a positive number                    |
      | vested above 100%     | I enter vested percentage "101"                | Vested percentage must be greater than 0 and at most 100 |
      | zero unit price       | I set the "price" of security "IBM" to "0"     | Unit price for IBM must be greater than 0                |
      | duplicate security    | I set the "symbol" of security "MSFT" to "IBM" | Duplicate security: IBM                                  |
