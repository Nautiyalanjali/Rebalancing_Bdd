@regression @e2e
Feature: Portfolio maintenance end to end
  The user can change the securities in the portfolio, recalculate, and reset to the defaults.

  Background:
    Given I open the Portfolio Rebalancer application

  @sanity @P1 @E2E-09
  Scenario: Restructure the portfolio - exit HD, add TSLA, fix an error and rebalance
    Given the account "ABC" has total asset of "200000" with "100" percent vested
    When I remove security "HD"
    And I add security "TSLA" with target "20" current "0" and price "245.50"
    And I update the securities as follows:
      | symbol | target | current |
      | IBM    | 25     | 30      |
      | MSFT   | 15     | 20      |
      | ORCL   | 20     | 30      |
      | AAPL   | 20     | 30      |
    And I click Calculate
    Then I should see the error "Total current % must equal 100 (currently 110)"
    When I set the "current" of security "AAPL" to "20"
    And I click Calculate
    Then no validation errors should be displayed
    And the trade output should be:
      | symbol | action | shares |
      | IBM    | SELL   | 66     |
      | MSFT   | SELL   | 111    |
      | ORCL   | SELL   | 90     |
      | AAPL   | HOLD   | 0      |
      | TSLA   | BUY    | 162    |
    And the trade output should match the expected rebalance calculation
    And after applying the trades every security should be within one share of its target value

  @P3 @E2E-10
  Scenario: Editing after a calculation clears old results and Reset restores the defaults
    When I click Calculate
    Then "IBM" should show action "BUY" with "66" shares
    When I set the "price" of security "IBM" to "100"
    Then no trade output should be displayed
    When I click Reset
    Then the account details should be:
      | account    | ABC    |
      | totalAsset | 100000 |
      | vested     | 100    |
    And fractional shares should be disabled
    And the holdings table should display:
      | symbol | target | current | price |
      | IBM    | 20     | 10      | 150   |
      | MSFT   | 20     | 20      | 90    |
      | ORCL   | 20     | 30      | 220   |
      | AAPL   | 20     | 20      | 450   |
      | HD     | 20     | 20      | 70    |
    When I click Calculate
    Then "IBM" should show action "BUY" with "66" shares
