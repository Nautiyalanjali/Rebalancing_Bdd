@regression @e2e @bva
Feature: Boundary value analysis
  Each input is tested just below, on and just above its limit.
  Limits: total asset > 0 | 0 < vested % <= 100 | unit price > 0 | 0 <= target % / current % <= 100
          target % and current % must each total exactly 100 | a trade smaller than one share rounds down to 0

  Background:
    Given I open the Portfolio Rebalancer application

  @P2 @E2E-11
  Scenario Outline: Boundary value is accepted - <case>
    When <action>
    And I click Calculate
    Then no validation errors should be displayed
    And "<symbol>" should show action "<result>" with "<shares>" shares

    Examples: Share rounding (IBM needs $ = 10% of investable asset, price 150)
      | case                                  | action                                        | symbol | result | shares  |
      | trade worth exactly one share         | I enter total asset "1500"                    | IBM    | BUY    | 1       |
      | trade worth just under one share      | I enter total asset "1499"                    | IBM    | BUY    | 0       |

    Examples: Total asset, vested % and unit price limits
      | case                                  | action                                        | symbol | result | shares  |
      | smallest total asset 0.01             | I enter total asset "0.01"                    | IBM    | BUY    | 0       |
      | smallest vested % 0.01                | I enter vested percentage "0.01"              | IBM    | BUY    | 0       |
      | vested % just under maximum 99.99     | I enter vested percentage "99.99"             | IBM    | BUY    | 66      |
      | vested % at maximum 100               | I enter vested percentage "100"               | ORCL   | SELL   | 45      |
      | smallest unit price 0.01              | I set the "price" of security "IBM" to "0.01" | IBM    | BUY    | 1000000 |

    Examples: Allocation % limits
      | case                                  | action                                                     | symbol | result | shares |
      | target 100% / current 0% (buy all)    | I load the "boundaryAllocation" portfolio from test data   | IBM    | BUY    | 666    |
      | target 0% / current 100% (sell all)   | I load the "boundaryAllocation" portfolio from test data   | ORCL   | SELL   | 454    |
      | smallest non-zero variance -0.01%     | I load the "minimalVariance" portfolio from test data      | IBM    | BUY    | 10     |
      | smallest non-zero variance +0.01%     | I load the "minimalVariance" portfolio from test data      | MSFT   | SELL   | 10     |

  @P2 @E2E-12
  Scenario Outline: Boundary value is rejected - <case>
    When <action>
    And I click Calculate
    Then I should see the error "<error>"
    And no trade output should be displayed

    Examples: Total asset, vested % and unit price limits
      | case                           | action                                         | error                                                    |
      | total asset just below 0       | I enter total asset "-0.01"                    | Total asset must be a positive number                    |
      | vested % at 0                  | I enter vested percentage "0"                  | Vested percentage must be greater than 0 and at most 100 |
      | vested % just above 100        | I enter vested percentage "100.01"             | Vested percentage must be greater than 0 and at most 100 |
      | unit price just below 0        | I set the "price" of security "IBM" to "-0.01" | Unit price for IBM must be greater than 0                |

    Examples: Single security % limits
      | case                           | action                                           | error                                       |
      | target % just above 100        | I set the "target" of security "IBM" to "100.01" | Target % for IBM must be between 0 and 100  |
      | target % just below 0          | I set the "target" of security "IBM" to "-0.01"  | Target % for IBM must be between 0 and 100  |
      | current % just above 100       | I set the "current" of security "IBM" to "100.01" | Current % for IBM must be between 0 and 100 |
      | current % just below 0         | I set the "current" of security "IBM" to "-0.01" | Current % for IBM must be between 0 and 100 |

    Examples: Allocation total must be exactly 100%
      | case                           | action                                           | error                                            |
      | target total just below 100    | I set the "target" of security "IBM" to "19.99"  | Total target % must equal 100 (currently 99.99)  |
      | target total just above 100    | I set the "target" of security "IBM" to "20.01"  | Total target % must equal 100 (currently 100.01) |
      | current total just below 100   | I set the "current" of security "IBM" to "9.99"  | Total current % must equal 100 (currently 99.99) |
      | current total just above 100   | I set the "current" of security "IBM" to "10.01" | Total current % must equal 100 (currently 100.01) |
