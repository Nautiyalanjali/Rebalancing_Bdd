// @ts-check
const { defineConfig, devices } = require('@playwright/test');
const { defineBddConfig, cucumberReporter } = require('playwright-bdd');
const { env } = require('./src/utils/env');

const testDir = defineBddConfig({
  features: 'features/**/*.feature',
  steps: ['src/fixtures/*.js', 'src/steps/**/*.js'],
  outputDir: '.features-gen',
  tags: env.tags,
});

// Map of supported browser keys -> Playwright project definitions (cross-browser support).
const browserProjects = {
  chromium: { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
  firefox: { name: 'firefox', use: { ...devices['Desktop Firefox'] } },
  webkit: { name: 'webkit', use: { ...devices['Desktop Safari'] } },
  chrome: { name: 'chrome', use: { ...devices['Desktop Chrome'], channel: 'chrome' } },
  edge: { name: 'edge', use: { ...devices['Desktop Edge'], channel: 'msedge' } },
  'mobile-chrome': { name: 'mobile-chrome', use: { ...devices['Pixel 7'] } },
  'mobile-safari': { name: 'mobile-safari', use: { ...devices['iPhone 14'] } },
};

const unknown = env.browsers.filter((b) => !browserProjects[b]);
if (unknown.length) {
  throw new Error(`Unsupported browser(s) in BROWSERS: ${unknown.join(', ')}. Use: ${Object.keys(browserProjects).join(', ')}`);
}

module.exports = defineConfig({
  testDir,
  fullyParallel: true,
  workers: env.workers,
  retries: process.env.CI ? Math.max(env.retries, 1) : env.retries,
  forbidOnly: !!process.env.CI,
  timeout: env.testTimeout,
  expect: { timeout: env.expectTimeout },
  outputDir: 'test-results',
  reporter: [
    ['list'],
    ['html', { outputFolder: 'reports/html-report', open: 'never' }],
    ['junit', { outputFile: 'reports/junit/results.xml' }],
    cucumberReporter('html', { outputFile: 'reports/cucumber/cucumber-report.html' }),
    cucumberReporter('json', { outputFile: 'reports/cucumber/cucumber-report.json' }),
  ],
  use: {
    baseURL: env.baseUrl,
    headless: env.headless,
    actionTimeout: env.actionTimeout,
    screenshot: /** @type {any} */ (env.screenshot),
    video: /** @type {any} */ (env.video),
    trace: /** @type {any} */ (env.trace),
  },
  projects: env.browsers.map((b) => browserProjects[b]),
  webServer: env.startLocalServer
    ? {
        command: 'node scripts/server.js',
        url: env.baseUrl,
        reuseExistingServer: !process.env.CI,
        env: { APP_PORT: String(env.appPort) },
        timeout: 30000,
      }
    : undefined,
});
