const { test: base, createBdd } = require('playwright-bdd');
const { RebalancePage } = require('../pages/RebalancePage');

// Custom fixtures: page objects injected into every step.
const test = base.extend({
  rebalancePage: async ({ page }, use) => {
    await use(new RebalancePage(page));
  },
});

const { Given, When, Then, Before, After } = createBdd(test);

module.exports = { test, Given, When, Then, Before, After };
