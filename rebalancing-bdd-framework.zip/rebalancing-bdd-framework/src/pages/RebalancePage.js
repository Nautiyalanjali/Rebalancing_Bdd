const { expect } = require('@playwright/test');
const { BasePage } = require('./BasePage');
const { HoldingsTableComponent } = require('./components/HoldingsTableComponent');
const { SummaryComponent } = require('./components/SummaryComponent');

class RebalancePage extends BasePage {
  /** @param {import('@playwright/test').Page} page */
  constructor(page) {
    super(page);
    this.heading = this.byTestId('app-title');
    this.accountName = this.byTestId('account-name');
    this.totalAsset = this.byTestId('total-asset');
    this.vestedPercent = this.byTestId('vested-percent');
    this.fractionalToggle = this.byTestId('fractional-toggle');
    this.calculateButton = this.byTestId('calculate');
    this.resetButton = this.byTestId('reset');
    this.errorBox = this.byTestId('error-messages');
    this.errorItems = this.byTestId('error-item');

    this.holdings = new HoldingsTableComponent(page);
    this.summary = new SummaryComponent(page);
  }

  async open() {
    await this.navigate('/');
    await expect(this.heading).toBeVisible();
  }

  async setAccount({ name, totalAsset, vested }) {
    if (name !== undefined) await this.accountName.fill(String(name));
    if (totalAsset !== undefined) await this.totalAsset.fill(String(totalAsset));
    if (vested !== undefined) await this.vestedPercent.fill(String(vested));
  }

  async setFractionalShares(enabled) {
    await this.fractionalToggle.setChecked(enabled);
  }

  async getAccount() {
    return {
      name: await this.accountName.inputValue(),
      totalAsset: await this.totalAsset.inputValue(),
      vested: await this.vestedPercent.inputValue(),
      fractional: await this.fractionalToggle.isChecked(),
    };
  }

  /** Clicks Calculate and waits until either the result summary or validation errors are rendered. */
  async calculate() {
    await this.calculateButton.click();
    await expect(this.summary.root.or(this.errorBox).filter({ visible: true }).first()).toBeVisible();
  }

  async reset() {
    await this.resetButton.click();
  }

  async getErrors() {
    if (!(await this.errorBox.isVisible())) return [];
    return (await this.errorItems.allTextContents()).map((e) => e.trim());
  }
}

module.exports = { RebalancePage };
