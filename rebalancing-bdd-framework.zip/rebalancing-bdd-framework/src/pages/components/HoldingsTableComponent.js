const FIELDS = ['symbol', 'target', 'current', 'price'];

class HoldingsTableComponent {
  /** @param {import('@playwright/test').Page} page */
  constructor(page) {
    this.page = page;
    this.rows = page.getByTestId('holdings-body').locator('tr.holding-row');
    this.addButton = page.getByTestId('add-security');
  }

  /** Reads every row's inputs and outputs in a single browser round-trip. */
  async readTable() {
    return this.rows.evaluateAll((trs) =>
      trs.map((tr) => {
        const el = (id) => tr.querySelector(`[data-testid="${id}"]`);
        return {
          symbol: el('symbol').value.trim().toUpperCase(),
          target: el('target').value,
          current: el('current').value,
          price: el('price').value,
          variance: el('variance').textContent.trim(),
          action: el('action').textContent.trim(),
          shares: el('shares').textContent.trim(),
          tradeValue: el('trade-value').textContent.trim(),
        };
      }),
    );
  }

  async getSymbols() {
    return (await this.readTable()).map((r) => r.symbol);
  }

  async getAllInputs() {
    return (await this.readTable()).map(({ symbol, target, current, price }) => ({ symbol, target, current, price }));
  }

  async getAllOutputs() {
    return (await this.readTable()).map(({ symbol, variance, action, shares, tradeValue }) => ({
      symbol,
      variance,
      action,
      shares,
      tradeValue,
    }));
  }

  async getOutput(symbol) {
    const out = (await this.getAllOutputs()).find((o) => o.symbol === String(symbol).toUpperCase());
    if (!out) throw new Error(`Security "${symbol}" not found in holdings table`);
    return out;
  }

  /** Returns the row locator whose symbol input matches (case-insensitive). */
  async rowFor(symbol) {
    const symbols = await this.getSymbols();
    const idx = symbols.indexOf(String(symbol).trim().toUpperCase());
    if (idx === -1) throw new Error(`Security "${symbol}" not found in holdings table. Found: ${symbols.join(', ')}`);
    return this.rows.nth(idx);
  }

  async setField(symbol, field, value) {
    if (!FIELDS.includes(field)) throw new Error(`Unknown holdings field "${field}". Use one of ${FIELDS.join(', ')}`);
    const row = await this.rowFor(symbol);
    await row.getByTestId(field).fill(String(value));
  }

  async addSecurity(holding = {}) {
    await this.addButton.click();
    const row = this.rows.last();
    for (const field of FIELDS) {
      if (holding[field] !== undefined) await row.getByTestId(field).fill(String(holding[field]));
    }
  }

  async removeSecurity(symbol) {
    const row = await this.rowFor(symbol);
    await row.getByTestId('remove-security').click();
  }

  async removeAll() {
    while ((await this.rows.count()) > 0) {
      await this.rows.first().getByTestId('remove-security').click();
    }
  }

  /** Replaces the whole portfolio with the given holdings. */
  async loadHoldings(holdings) {
    await this.removeAll();
    for (const h of holdings) await this.addSecurity(h);
  }
}

module.exports = { HoldingsTableComponent };
