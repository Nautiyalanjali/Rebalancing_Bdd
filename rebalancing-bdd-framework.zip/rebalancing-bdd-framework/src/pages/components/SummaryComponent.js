class SummaryComponent {
  /** @param {import('@playwright/test').Page} page */
  constructor(page) {
    this.root = page.getByTestId('summary');
    this.investableAsset = page.getByTestId('investable-asset');
    this.totalBuy = page.getByTestId('total-buy');
    this.totalSell = page.getByTestId('total-sell');
    this.residualCash = page.getByTestId('residual-cash');
    this.statusMessage = page.getByTestId('status-message');
  }

  async isVisible() {
    return this.root.isVisible();
  }

  async getValues() {
    return {
      investableAsset: (await this.investableAsset.textContent()).trim(),
      totalBuy: (await this.totalBuy.textContent()).trim(),
      totalSell: (await this.totalSell.textContent()).trim(),
      residualCash: (await this.residualCash.textContent()).trim(),
      statusMessage: (await this.statusMessage.textContent()).trim(),
    };
  }
}

module.exports = { SummaryComponent };
