const { expect } = require('@playwright/test');
const { Then, test } = require('../fixtures/fixtures');
const { calculateRebalance, applyTrades } = require('../utils/rebalanceCalculator');

/** Reads the current inputs from the UI and computes the expected output with the independent oracle. */
async function expectedFromUi(rebalancePage) {
  const account = await rebalancePage.getAccount();
  const holdings = await rebalancePage.holdings.getAllInputs();
  return calculateRebalance({ totalAsset: account.totalAsset, vested: account.vested, fractional: account.fractional, holdings });
}

/** Lets a step report every soft-assertion mismatch, then stops the scenario at that step if any occurred. */
async function withSoftAssertions(fn) {
  const before = test.info().errors.length;
  await fn();
  const added = test.info().errors.length - before;
  if (added > 0) throw new Error(`${added} trade output mismatch(es) found - see soft assertion errors above`);
}

function findOutput(outputs, symbol) {
  const out = outputs.find((o) => o.symbol === String(symbol).toUpperCase());
  if (!out) throw new Error(`Security "${symbol}" not found. Found: ${outputs.map((o) => o.symbol).join(', ')}`);
  return out;
}

Then('{string} should show action {string} with {string} shares', async ({ rebalancePage }, symbol, action, shares) => {
  const out = await rebalancePage.holdings.getOutput(symbol);
  expect(out.action, `${symbol} action`).toBe(action);
  expect(Number(out.shares), `${symbol} shares`).toBeCloseTo(Number(shares), 4);
});

Then('the trade output should be:', async ({ rebalancePage }, dataTable) => {
  const outputs = await rebalancePage.holdings.getAllOutputs();
  await withSoftAssertions(async () => {
    for (const row of dataTable.hashes()) {
      const out = findOutput(outputs, row.symbol);
      expect.soft(out.action, `${row.symbol} action`).toBe(row.action);
      expect.soft(Number(out.shares), `${row.symbol} shares`).toBeCloseTo(Number(row.shares), 4);
      if (row.tradeValue !== undefined) {
        expect.soft(Number(out.tradeValue), `${row.symbol} trade value`).toBeCloseTo(Number(row.tradeValue), 2);
      }
    }
  });
});

Then('the trade output should match the expected rebalance calculation', async ({ rebalancePage }) => {
  const expected = await expectedFromUi(rebalancePage);
  const outputs = await rebalancePage.holdings.getAllOutputs();
  expect(outputs.map((a) => a.symbol)).toEqual(expected.trades.map((t) => t.symbol));
  await withSoftAssertions(async () => {
    for (const t of expected.trades) {
      const a = findOutput(outputs, t.symbol);
      expect.soft(a.action, `${t.symbol} action`).toBe(t.action);
      expect.soft(Number(a.shares), `${t.symbol} shares`).toBeCloseTo(t.shares, 4);
      expect.soft(Number(a.tradeValue), `${t.symbol} trade value`).toBeCloseTo(t.tradeValue, 2);
    }
  });
});

Then('every security should show action {string} with {string} shares', async ({ rebalancePage }, action, shares) => {
  const outputs = await rebalancePage.holdings.getAllOutputs();
  await withSoftAssertions(async () => {
    for (const out of outputs) {
      expect.soft(out.action, `${out.symbol} action`).toBe(action);
      expect.soft(Number(out.shares), `${out.symbol} shares`).toBe(Number(shares));
    }
  });
});

Then(
  'after applying the trades every security should be within one share of its target value',
  async ({ rebalancePage }) => {
    const expected = await expectedFromUi(rebalancePage);
    const outputs = await rebalancePage.holdings.getAllOutputs();
    // Use the shares produced by the APPLICATION (not the oracle) to verify the business goal.
    const appTrades = expected.trades.map((t) => {
      const a = findOutput(outputs, t.symbol);
      return { ...t, action: a.action, shares: Number(a.shares), tradeValue: Number(a.shares) * t.price };
    });
    await withSoftAssertions(async () => {
      for (const p of applyTrades({ investable: expected.investable, trades: appTrades })) {
        expect
          .soft(p.remainingDeviation, `${p.symbol}: post-trade $${p.postTradeValue.toFixed(2)} vs target $${p.targetValue.toFixed(2)}`)
          .toBeLessThan(p.price + 0.01);
      }
    });
  },
);

Then('no trade output should be displayed', async ({ rebalancePage }) => {
  for (const out of await rebalancePage.holdings.getAllOutputs()) {
    expect(out.action, `${out.symbol} action`).toBe('');
    expect(out.shares, `${out.symbol} shares`).toBe('');
  }
  await expect(rebalancePage.summary.root).toBeHidden();
});
