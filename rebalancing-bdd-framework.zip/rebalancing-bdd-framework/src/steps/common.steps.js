const { expect } = require('@playwright/test');
const { Given, When, Then } = require('../fixtures/fixtures');
const { env } = require('../utils/env');
const portfolios = require('../../test-data/portfolios.json');

Given('I open the Portfolio Rebalancer application', async ({ rebalancePage }) => {
  await rebalancePage.open();
});

Given('the account details from the environment are entered', async ({ rebalancePage }) => {
  await rebalancePage.setAccount(env.account);
});

Given(
  'the account {string} has total asset of {string} with {string} percent vested',
  async ({ rebalancePage }, name, totalAsset, vested) => {
    await rebalancePage.setAccount({ name, totalAsset, vested });
  },
);

Given('I load the {string} portfolio from test data', async ({ rebalancePage }, key) => {
  const p = portfolios[key];
  if (!p) throw new Error(`Portfolio "${key}" not found in test-data/portfolios.json`);
  await rebalancePage.setAccount({ totalAsset: p.totalAsset, vested: p.vested });
  await rebalancePage.holdings.loadHoldings(p.holdings);
});

When('I enter total asset {string}', async ({ rebalancePage }, value) => {
  await rebalancePage.setAccount({ totalAsset: value });
});

When('I enter vested percentage {string}', async ({ rebalancePage }, value) => {
  await rebalancePage.setAccount({ vested: value });
});

When('I enable fractional shares', async ({ rebalancePage }) => {
  await rebalancePage.setFractionalShares(true);
});

When('I click Calculate', async ({ rebalancePage }) => {
  await rebalancePage.calculate();
});

When('I click Reset', async ({ rebalancePage }) => {
  await rebalancePage.reset();
});

Then('the account details should be:', async ({ rebalancePage }, dataTable) => {
  const expected = dataTable.rowsHash();
  const actual = await rebalancePage.getAccount();
  expect(actual.name).toBe(expected.account);
  expect(actual.totalAsset).toBe(expected.totalAsset);
  expect(actual.vested).toBe(expected.vested);
});

Then('fractional shares should be disabled', async ({ rebalancePage }) => {
  await expect(rebalancePage.fractionalToggle).not.toBeChecked();
});
