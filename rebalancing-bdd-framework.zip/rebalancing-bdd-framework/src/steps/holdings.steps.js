const { expect } = require('@playwright/test');
const { Given, When, Then } = require('../fixtures/fixtures');

Given('the account holds the following securities:', async ({ rebalancePage }, dataTable) => {
  await rebalancePage.holdings.loadHoldings(dataTable.hashes());
});

When(
  'I add security {string} with target {string} current {string} and price {string}',
  async ({ rebalancePage }, symbol, target, current, price) => {
    await rebalancePage.holdings.addSecurity({ symbol, target, current, price });
  },
);

When('I remove security {string}', async ({ rebalancePage }, symbol) => {
  await rebalancePage.holdings.removeSecurity(symbol);
});

When('I set the {string} of security {string} to {string}', async ({ rebalancePage }, field, symbol, value) => {
  await rebalancePage.holdings.setField(symbol, field, value);
});

When('I update the securities as follows:', async ({ rebalancePage }, dataTable) => {
  for (const { symbol, ...fields } of dataTable.hashes()) {
    for (const [field, value] of Object.entries(fields)) {
      if (value !== '') await rebalancePage.holdings.setField(symbol, field, value);
    }
  }
});

Then('the holdings table should display:', async ({ rebalancePage }, dataTable) => {
  const expected = dataTable.hashes();
  const actual = await rebalancePage.holdings.readTable();
  expect(actual.map((r) => r.symbol)).toEqual(expected.map((r) => r.symbol));
  for (const row of expected) {
    const a = actual.find((r) => r.symbol === row.symbol);
    expect(Number(a.target), `${row.symbol} target`).toBe(Number(row.target));
    expect(Number(a.current), `${row.symbol} current`).toBe(Number(row.current));
    expect(Number(a.price), `${row.symbol} price`).toBe(Number(row.price));
    if (row.variance !== undefined) {
      expect(Number(a.variance), `${row.symbol} variance`).toBe(Number(row.variance));
    }
  }
});
