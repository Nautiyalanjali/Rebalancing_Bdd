const { expect } = require('@playwright/test');
const { Then } = require('../fixtures/fixtures');
const { calculateRebalance } = require('../utils/rebalanceCalculator');

Then('the trade summary should show:', async ({ rebalancePage }, dataTable) => {
  await expect(rebalancePage.summary.root).toBeVisible();
  const expected = dataTable.rowsHash();
  const actual = await rebalancePage.summary.getValues();
  for (const [field, value] of Object.entries(expected)) {
    expect.soft(actual[field], `summary ${field}`).toBe(value);
  }
});

Then('the trade summary should match the expected rebalance calculation', async ({ rebalancePage }) => {
  const account = await rebalancePage.getAccount();
  const holdings = await rebalancePage.holdings.getAllInputs();
  const exp = calculateRebalance({ totalAsset: account.totalAsset, vested: account.vested, fractional: account.fractional, holdings });
  const actual = await rebalancePage.summary.getValues();
  expect(Number(actual.investableAsset)).toBeCloseTo(exp.investable, 2);
  expect(Number(actual.totalBuy)).toBeCloseTo(exp.totalBuy, 2);
  expect(Number(actual.totalSell)).toBeCloseTo(exp.totalSell, 2);
  expect(Number(actual.residualCash)).toBeCloseTo(exp.residualCash, 2);
});
