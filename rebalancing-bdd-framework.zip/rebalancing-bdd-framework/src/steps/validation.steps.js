const { expect } = require('@playwright/test');
const { Then } = require('../fixtures/fixtures');

Then('I should see the error {string}', async ({ rebalancePage }, message) => {
  await expect(rebalancePage.errorBox).toBeVisible();
  expect(await rebalancePage.getErrors()).toContain(message);
});

Then('no validation errors should be displayed', async ({ rebalancePage }) => {
  await expect(rebalancePage.errorBox).toBeHidden();
});
