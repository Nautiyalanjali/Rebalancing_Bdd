const path = require('path');
const fs = require('fs');
const dotenv = require('dotenv');

// Loads config/.env.<TEST_ENV> (default "local"). Variables already set in the shell/CI take precedence.
const envName = process.env.TEST_ENV || 'local';
const envFile = path.resolve(__dirname, '..', '..', 'config', `.env.${envName}`);
if (!fs.existsSync(envFile)) {
  throw new Error(`Environment file not found: ${envFile}. Valid TEST_ENV values: local, qa, uat`);
}
dotenv.config({ path: envFile, quiet: true });

const str = (key, def) => (process.env[key] !== undefined && process.env[key] !== '' ? process.env[key] : def);
const num = (key, def) => Number(str(key, def));
const bool = (key, def) => String(str(key, def)).toLowerCase() === 'true';

const env = {
  envName: str('ENV_NAME', envName),
  baseUrl: str('BASE_URL', 'http://localhost:3000'),
  startLocalServer: bool('START_LOCAL_SERVER', 'true'),
  appPort: num('APP_PORT', 3000),
  browsers: str('BROWSERS', 'chromium')
    .split(',')
    .map((b) => b.trim())
    .filter(Boolean),
  headless: bool('HEADLESS', 'true'),
  workers: /%$/.test(str('WORKERS', '50%')) ? str('WORKERS', '50%') : num('WORKERS', 2),
  retries: num('RETRIES', 0),
  testTimeout: num('TEST_TIMEOUT', 30000),
  expectTimeout: num('EXPECT_TIMEOUT', 5000),
  actionTimeout: num('ACTION_TIMEOUT', 10000),
  screenshot: str('SCREENSHOT', 'only-on-failure'),
  video: str('VIDEO', 'retain-on-failure'),
  trace: str('TRACE', 'retain-on-failure'),
  tags: str('TAGS', undefined),
  account: {
    name: str('ACCOUNT_NAME', 'ABC'),
    totalAsset: str('TOTAL_ASSET', '100000'),
    vested: str('VESTED_PERCENT', '100'),
  },
};

module.exports = { env };
