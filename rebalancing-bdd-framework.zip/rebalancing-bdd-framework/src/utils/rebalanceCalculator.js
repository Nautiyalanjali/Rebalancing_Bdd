/*
 * Independent test oracle: computes the EXPECTED rebalance output from inputs.
 * Used by data-driven scenarios so expected values are never copied from the UI.
 */
const EPS = 1e-9;

function calculateRebalance({ totalAsset, vested = 100, holdings, fractional = false }) {
  const investable = (Number(totalAsset) * Number(vested)) / 100;
  let totalBuy = 0;
  let totalSell = 0;

  const trades = holdings.map((h) => {
    const target = Number(h.target);
    const current = Number(h.current);
    const price = Number(h.price);
    const variance = current - target;
    const action = Math.abs(variance) < 0.0001 ? 'HOLD' : variance < 0 ? 'BUY' : 'SELL';
    const exactShares = action === 'HOLD' ? 0 : ((Math.abs(variance) / 100) * investable) / price;
    const shares = fractional ? Math.round(exactShares * 1e4) / 1e4 : Math.floor(exactShares + EPS);
    const tradeValue = shares * price;
    if (action === 'BUY') totalBuy += tradeValue;
    if (action === 'SELL') totalSell += tradeValue;
    return { symbol: String(h.symbol).toUpperCase(), target, current, price, variance, action, exactShares, shares, tradeValue };
  });

  return { investable, trades, totalBuy, totalSell, residualCash: totalSell - totalBuy };
}

/**
 * Applies the trades to the starting portfolio and returns each security's post-trade
 * value and its remaining deviation from the target value (in $).
 */
function applyTrades({ investable, trades }) {
  return trades.map((t) => {
    const currentValue = (t.current / 100) * investable;
    const targetValue = (t.target / 100) * investable;
    const signed = t.action === 'BUY' ? t.tradeValue : t.action === 'SELL' ? -t.tradeValue : 0;
    const postTradeValue = currentValue + signed;
    return { ...t, postTradeValue, targetValue, remainingDeviation: Math.abs(postTradeValue - targetValue) };
  });
}

module.exports = { calculateRebalance, applyTrades };
